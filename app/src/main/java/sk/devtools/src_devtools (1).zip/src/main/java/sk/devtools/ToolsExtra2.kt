@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)

package sk.devtools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.EncodeHintType
import com.google.zxing.LuminanceSource
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

// ───────────────────────── WebSocket tester ─────────────────────────

@Composable
fun WsTool() = Page("WebSocket tester", "Pripojí sa na ws:// alebo wss://, pošle správu a vypíše všetko, čo server pošle späť.") {
    var u by rememberSaveable { mutableStateOf("") }
    var m by rememberSaveable { mutableStateOf("") }
    var h by rememberSaveable { mutableStateOf("") }
    var s by rememberSaveable { mutableStateOf("10 s") }
    Field(u, { u = it }, "wss://echo.example.com/socket")
    Field(m, { m = it }, "Správa na odoslanie (voliteľné)", lines = 3)
    Field(h, { h = it }, "Hlavičky (Origin, Authorization, ...): Name: value", lines = 2)
    Text("Ako dlho počúvať", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Chips(listOf("5 s", "10 s", "30 s", "60 s"), s) { s = it }
    Run("Pripojiť", u.isNotBlank()) {
        val sec = s.substringBefore(' ').toIntOrNull() ?: 10
        withContext(Dispatchers.IO) { wsTest(u, m, parseHeaders(h), sec) }
    }
}

// ───────────────────────── GeoIP + reverzné DNS ─────────────────────────

@Composable
fun GeoTool() = Page("GeoIP a reverzné DNS", "Poloha, sieť (ASN, ISP) a reverzný DNS záznam pre IP adresu alebo doménu.") {
    var q by rememberSaveable { mutableStateOf("") }
    Field(q, { q = it }, "8.8.8.8 alebo example.com")
    Run("Vyhľadať", q.isNotBlank()) { geoLookup(q) }
}

// ───────────────────────── HTTP/2, HTTP/3 a TLS ─────────────────────────

@Composable
fun ProtoTool() = Page("HTTP/2, HTTP/3 a TLS", "Ktoré verzie TLS server prijíma, či podporuje HTTP/2 (ALPN) a či ohlasuje HTTP/3.") {
    var h by rememberSaveable { mutableStateOf("") }
    Field(h, { h = it }, "example.com alebo example.com:8443")
    Run("Skontrolovať", h.isNotBlank()) { withContext(Dispatchers.IO) { protoCheck(h) } }
}

// ───────────────────────── JWT generátor ─────────────────────────

@Composable
fun JwtGenTool() = Page("JWT generátor", "Vytvorí a podpíše JWT algoritmom HMAC (HS256, HS384, HS512). Všetko beží lokálne.") {
    var alg by rememberSaveable { mutableStateOf("HS256") }
    var hd by rememberSaveable { mutableStateOf("{\"typ\":\"JWT\"}") }
    var pl by rememberSaveable { mutableStateOf("{\n  \"sub\": \"1234567890\",\n  \"name\": \"Ján Novák\"\n}") }
    var sec by rememberSaveable { mutableStateOf("") }
    var iat by rememberSaveable { mutableStateOf("iat: teraz") }
    var exp by rememberSaveable { mutableStateOf("bez exp") }
    Chips(listOf("HS256", "HS384", "HS512"), alg) { alg = it }
    Field(hd, { hd = it }, "Hlavička (JSON, alg sa doplní sám)", lines = 2)
    Field(pl, { pl = it }, "Payload (JSON)", lines = 6)
    Field(sec, { sec = it }, "Tajný kľúč")
    Chips(listOf("iat: teraz", "bez iat"), iat) { iat = it }
    Chips(listOf("bez exp", "exp +1 h", "exp +24 h", "exp +7 dní", "exp +30 dní"), exp) { exp = it }
    if (sec.isEmpty()) Err("Zadaj tajný kľúč.")
    else {
        val expSec = when (exp) {
            "exp +1 h" -> 3600L
            "exp +24 h" -> 86400L
            "exp +7 dní" -> 7 * 86400L
            "exp +30 dní" -> 30 * 86400L
            else -> null
        }
        val r = remember(alg, hd, pl, sec, iat, exp) { runCatching { jwtMake(alg, hd, pl, sec, iat == "iat: teraz", expSec) } }
        r.onSuccess { Out(it, "Token") }
        r.onFailure { Err(it.message ?: "Token sa nepodarilo vytvoriť.") }
    }
}

// ───────────────────────── Formátovač XML, HTML, SQL ─────────────────────────

@Composable
fun FmtTool() = Page("Formátovač XML, HTML a SQL", "Prehľadné odsadenie alebo minifikácia kódu. Beží lokálne.") {
    var t by rememberSaveable { mutableStateOf("XML") }
    var mode by rememberSaveable { mutableStateOf("Formátovať") }
    var src by rememberSaveable { mutableStateOf("") }
    Chips(listOf("XML", "HTML", "SQL"), t) { t = it }
    Chips(listOf("Formátovať", "Minifikovať"), mode) { mode = it }
    Field(src, { src = it }, "Vstup", lines = 8)
    if (src.isNotBlank()) {
        val r = remember(t, mode, src) {
            runCatching {
                when (t) {
                    "SQL" -> if (mode == "Formátovať") formatSql(src) else minifySql(src)
                    else -> if (mode == "Formátovať") formatMarkup(src, t == "HTML") else minifyMarkup(src)
                }
            }
        }
        r.onSuccess { Out(it, "Výsledok (${it.length} znakov)") }
        r.onFailure { Err(it.message ?: "Formátovanie zlyhalo.") }
    }
}

// ───────────────────────── QR kód ─────────────────────────
// Vyžaduje závislosť: implementation("com.google.zxing:core:3.5.3")

fun qrBitmap(text: String, ecc: String): Bitmap {
    val level = when (ecc) {
        "L" -> ErrorCorrectionLevel.L
        "Q" -> ErrorCorrectionLevel.Q
        "H" -> ErrorCorrectionLevel.H
        else -> ErrorCorrectionLevel.M
    }
    val hints = mapOf<EncodeHintType, Any>(
        EncodeHintType.ERROR_CORRECTION to level,
        EncodeHintType.MARGIN to 2,
        EncodeHintType.CHARACTER_SET to "UTF-8"
    )
    val m = try {
        QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, hints)
    } catch (e: Exception) {
        throw Exception("Text je príliš dlhý na zakódovanie do QR kódu.")
    }
    val scale = maxOf(1, minOf(12, 1500 / m.width))
    val w = m.width * scale
    val h = m.height * scale
    val black = 0xFF000000.toInt()
    val white = 0xFFFFFFFF.toInt()
    val px = IntArray(w * h)
    for (y in 0 until h) for (x in 0 until w) px[y * w + x] = if (m.get(x / scale, y / scale)) black else white
    val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    b.setPixels(px, 0, w, 0, 0, w, h)
    return b
}

fun decodeCode(ctx: Context, uri: Uri): String {
    val cr = ctx.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        ?: throw Exception("Obrázok sa nepodarilo načítať.")
    val w = bmp.width
    val h = bmp.height
    val px = IntArray(w * h)
    bmp.getPixels(px, 0, w, 0, 0, w, h)
    val src = RGBLuminanceSource(w, h, px)
    val hints = mapOf<DecodeHintType, Any>(DecodeHintType.TRY_HARDER to true)
    val reader = MultiFormatReader()
    fun attempt(s: LuminanceSource) = runCatching { reader.decode(BinaryBitmap(HybridBinarizer(s)), hints) }.getOrNull()
    val r = attempt(src) ?: attempt(src.invert()) ?: throw Exception("V obrázku sa nenašiel žiadny QR ani čiarový kód.")
    return r.text + "\n\n(formát: ${r.barcodeFormat})"
}

@Composable
fun QrTool() = Page("QR kód", "Vytvorí QR kód z textu alebo prečíta QR či čiarový kód z obrázka v galérii.") {
    var mode by rememberSaveable { mutableStateOf("Generátor") }
    Chips(listOf("Generátor", "Čítačka"), mode) { mode = it }
    if (mode == "Generátor") QrGen() else QrRead()
}

@Composable
private fun QrGen() {
    var t by rememberSaveable { mutableStateOf("") }
    var ecc by rememberSaveable { mutableStateOf("M") }
    Field(t, { t = it }, "Text alebo URL", lines = 3, mono = false)
    Text("Úroveň opravy chýb", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Chips(listOf("L", "M", "Q", "H"), ecc) { ecc = it }
    if (t.isNotEmpty()) {
        val r = remember(t, ecc) { runCatching { qrBitmap(t, ecc) } }
        r.onSuccess { b -> QrImage(b) }
        r.onFailure { Err(it.message ?: "QR kód sa nepodarilo vytvoriť.") }
    }
}

@Composable
private fun QrImage(b: Bitmap) {
    val ctx = LocalContext.current
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri: Uri? ->
        if (uri != null) runCatching { ctx.contentResolver.openOutputStream(uri)?.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) } }
    }
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Image(
            bitmap = b.asImageBitmap(), contentDescription = "QR kód", filterQuality = FilterQuality.None,
            modifier = Modifier.size(280.dp).clip(RoundedCornerShape(20.dp))
        )
    }
    Act("Uložiť ako PNG") { saver.launch("qr-kod.png") }
}

@Composable
private fun QrRead() {
    val ctx = LocalContext.current
    var res by remember { mutableStateOf<Result<String>?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) res = runCatching { decodeCode(ctx, uri) }
    }
    Act("Vybrať obrázok s kódom") { pick.launch("image/*") }
    Res(res, "Obsah kódu")
}

// ───────────────────────── Záloha obľúbených, nedávnych a histórie ─────────────────────────

object Backup {
    fun export(c: Context): String {
        val o = JSONObject()
        o.put("app", "devtools")
        o.put("version", 1)
        o.put("fav", JSONArray(Store.ids(c, "fav")))
        o.put("recent", JSONArray(Store.ids(c, "recent")))
        o.put("autopaste", Store.get(c, "autopaste") != "0")
        o.put("hist_req", JSONArray(Store.get(c, "hist_req") ?: "[]"))
        o.put("hist_redir", JSONArray(Store.get(c, "hist_redir") ?: "[]"))
        return o.toString(2)
    }

    // Prepíše aktuálne dáta dátami zo zálohy. Vráti krátke zhrnutie.
    fun restore(c: Context, txt: String): String {
        val o = JSONObject(txt)
        if (o.optString("app") != "devtools") throw Exception("Nie je to záloha DevTools.")
        val valid = TOOLS.map { it.id }.toSet()
        fun ids(k: String): List<String> {
            val a = o.optJSONArray(k) ?: return emptyList()
            return (0 until a.length()).map { a.optString(it) }.filter { it in valid }.distinct()
        }
        val fav = ids("fav")
        Store.saveIds(c, "fav", fav)
        Store.saveIds(c, "recent", ids("recent").take(8))
        Store.put(c, "autopaste", if (o.optBoolean("autopaste", true)) "1" else "0")
        var hist = 0
        for (k in listOf("hist_req", "hist_redir")) {
            o.optJSONArray(k)?.let { Store.put(c, k, it.toString()); hist += it.length() }
        }
        return "${fav.size} obľúbených, $hist záznamov histórie"
    }
}
