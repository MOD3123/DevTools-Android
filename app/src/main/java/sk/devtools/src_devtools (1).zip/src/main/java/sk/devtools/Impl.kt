package sk.devtools

import android.os.Build
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigInteger
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Base64
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

private fun num(s: String) = s.trim().replace(',', '.').toDoubleOrNull()

private val BODY_METHODS = listOf("POST", "PUT", "PATCH", "DELETE")
private const val FOLLOW = "Nasledovať presmerovania"
private val REDIR_CODES = intArrayOf(301, 302, 303, 307, 308)

@Composable
fun ReqTool() = Page("HTTP požiadavky", "Odošle HTTP požiadavku s vlastnými hlavičkami, telom a autentifikáciou a ukáže stav, hlavičky a telo odpovede.") {
    var u by rememberSaveable { mutableStateOf("") }
    var m by rememberSaveable { mutableStateOf("GET") }
    var h by rememberSaveable { mutableStateOf("") }
    var b by rememberSaveable { mutableStateOf("") }
    var f by rememberSaveable { mutableStateOf(FOLLOW) }
    var ua by rememberSaveable { mutableStateOf(UAS[0].first) }
    var au by rememberSaveable { mutableStateOf(AUTH_NONE) }
    var user by rememberSaveable { mutableStateOf("") }
    var pass by rememberSaveable { mutableStateOf("") }
    var tok by rememberSaveable { mutableStateOf("") }
    val hist = rememberHist("hist_req")

    Field(u, { u = it }, "URL alebo IP adresa")
    Chips(listOf("GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"), m) { m = it }
    UaPicker(ua) { ua = it }
    Field(h, { h = it }, "Hlavičky (jedna na riadok): Name: value", lines = 3)
    if (m in BODY_METHODS) Field(b, { b = it }, "Telo požiadavky (BODY)", lines = 4)
    AuthFields(au, { au = it }, user, { user = it }, pass, { pass = it }, tok, { tok = it })
    Chips(listOf(FOLLOW, "Nenasledovať"), f) { f = it }

    val follow = f == FOLLOW
    val basic = if (au == "Basic") user to pass else null
    val bearer = if (au == "Bearer") tok else null
    val body = if (m in BODY_METHODS) b.ifEmpty { null } else null
    val hs = withUa(parseHeaders(h), ua) +
        (if (!bearer.isNullOrBlank()) listOf("Authorization" to "Bearer " + bearer.trim()) else emptyList())

    Run("Odoslať", u.isNotBlank()) {
        hist.add(
            JSONObject().put("k", "$m ${u.trim()}").put("label", "$m ${u.trim()}")
                .put("u", u.trim()).put("m", m).put("h", h).put("b", b).put("f", f)
                .put("ua", ua).put("au", au).put("user", user)
        )
        withContext(Dispatchers.IO) { httpFetch(u, m, hs, body, basic, follow).report() }
    }
    if (u.isNotBlank()) Out(toCurl(u, m, withUa(parseHeaders(h), ua), body, basic, bearer, follow), "Export ako cURL")
    HistoryBox(hist) { o ->
        u = o.optString("u"); m = o.optString("m", "GET"); h = o.optString("h"); b = o.optString("b")
        f = o.optString("f", FOLLOW); ua = o.optString("ua", UAS[0].first)
        au = o.optString("au", AUTH_NONE); user = o.optString("user"); pass = ""; tok = ""
    }
}

@Composable
fun RedirTool() = Page("Kontrola presmerovaní", "Sleduje reťazec presmerovaní krok za krokom a ukáže stavové kódy, časy a konečnú adresu. Môžeš zadať viac URL naraz.") {
    var u by rememberSaveable { mutableStateOf("") }
    var m by rememberSaveable { mutableStateOf("GET") }
    var h by rememberSaveable { mutableStateOf("") }
    var b by rememberSaveable { mutableStateOf("") }
    var ua by rememberSaveable { mutableStateOf(UAS[0].first) }
    var au by rememberSaveable { mutableStateOf(AUTH_NONE) }
    var user by rememberSaveable { mutableStateOf("") }
    var pass by rememberSaveable { mutableStateOf("") }
    var tok by rememberSaveable { mutableStateOf("") }
    val hist = rememberHist("hist_redir")

    Field(u, { u = it }, "URL alebo IP adresa (viac adries každú na nový riadok, max. 10)", lines = 2)
    Chips(listOf("GET", "HEAD", "POST"), m) { m = it }
    UaPicker(ua) { ua = it }
    Field(h, { h = it }, "Hlavičky (jedna na riadok): Name: value", lines = 2)
    if (m == "POST") Field(b, { b = it }, "Telo požiadavky (BODY)", lines = 4)
    AuthFields(au, { au = it }, user, { user = it }, pass, { pass = it }, tok, { tok = it })

    Run("Skontrolovať", u.isNotBlank()) {
        val urls = u.lines().map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(10)
        hist.add(
            JSONObject().put("k", "$m ${urls.joinToString(" ")}").put("label", "$m ${urls.joinToString("  ·  ")}")
                .put("u", u.trim()).put("m", m).put("h", h).put("b", b)
                .put("ua", ua).put("au", au).put("user", user)
        )
        val hs = withUa(parseHeaders(h), ua)
        val results = coroutineScope {
            urls.map { url ->
                async {
                    url to traceRequest(
                        url, m, headers = hs, body = if (m == "POST") b.ifEmpty { null } else null,
                        basic = if (au == "Basic") user to pass else null,
                        bearer = if (au == "Bearer") tok else null
                    )
                }
            }.awaitAll()
        }
        fun count(hops: List<Hop>) = hops.count { it.status in REDIR_CODES }
        fun last(hops: List<Hop>) = hops.lastOrNull { it.error.isNullOrBlank() && it.status > 0 }
        fun head(hops: List<Hop>) = buildString {
            append("Presmerovaní: ${count(hops)}")
            last(hops)?.let { append("  ·  konečný stav: ${it.status}\nKonečná adresa: ${it.url}") }
        }
        if (results.size == 1) head(results[0].second) + "\n\n" + results[0].second.render()
        else {
            val sum = results.joinToString("\n") { (url, hops) ->
                val l = last(hops)
                "• $url\n  " + (if (l != null) "${l.status}, presmerovaní: ${count(hops)}, cieľ: ${l.url}" else "chyba: " + (hops.lastOrNull()?.error ?: "bez odpovede"))
            }
            "Skontrolovaných adries: ${results.size}\n\n$sum\n\n" +
                results.joinToString("\n\n") { (url, hops) -> "━━━ $url ━━━\n" + hops.render() }
        }
    }
    HistoryBox(hist) { o ->
        u = o.optString("u"); m = o.optString("m", "GET"); h = o.optString("h"); b = o.optString("b")
        ua = o.optString("ua", UAS[0].first); au = o.optString("au", AUTH_NONE); user = o.optString("user"); pass = ""; tok = ""
    }
}

@Composable
fun IpTool() = Page("What is my IP", "Tvoja verejná IP adresa a informácie o zariadení.") {
    var ip by remember { mutableStateOf("…") }
    var n by remember { mutableIntStateOf(0) }
    LaunchedEffect(n) {
        ip = "…"
        ip = try { JSONObject(http("https://api.ipify.org?format=json")).getString("ip") } catch (e: Exception) { "Nedostupné" }
    }
    Out(ip, "IP adresa")
    Act("Obnoviť") { n++ }
    val dm = LocalContext.current.resources.displayMetrics
    Out(
        "Zariadenie: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "Jazyk: ${Locale.getDefault().toLanguageTag()}\nČasové pásmo: ${TimeZone.getDefault().id}\nObrazovka: ${dm.widthPixels}×${dm.heightPixels}",
        "Zariadenie"
    )
}

@Composable
fun DnsTool() = Page("DNS lookup", "Záznamy A, AAAA, CNAME, MX, NS, TXT, SOA, CAA, SRV a reverzné PTR (zadaj IP adresu).") {
    var nm by rememberSaveable { mutableStateOf("") }
    var t by rememberSaveable { mutableStateOf("ALL") }
    Field(nm, { nm = it }, "example.com alebo 0.0.0.0")
    Chips(listOf("ALL", "A", "AAAA", "CNAME", "MX", "NS", "TXT", "SOA", "CAA", "SRV", "PTR"), t) { t = it }
    Run("Vyhľadať", nm.isNotBlank()) {
        dnsLookup(nm, t)
    }
}

@Composable
fun TsTool() = Page("Unix timestamp", "Prevod medzi timestampom a dátumom.") {
    var now by remember { mutableLongStateOf(System.currentTimeMillis() / 1000) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis() / 1000; delay(1000) } }
    Out(now.toString(), "Aktuálny timestamp")
    var t by rememberSaveable { mutableStateOf("") }
    Field(t, { t = it }, "Timestamp (sekundy alebo milisekundy)")
    t.trim().toLongOrNull()?.let { n ->
        val i = Instant.ofEpochMilli(if (n > 99_999_999_999L) n else n * 1000)
        Out("UTC      $i\nLokálne  ${i.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.RFC_1123_DATE_TIME)}")
    }
    var d by rememberSaveable { mutableStateOf("2024-01-01T00:00") }
    Field(d, { d = it }, "Dátum a čas (ISO, lokálny)")
    runCatching { LocalDateTime.parse(d.trim()).atZone(ZoneId.systemDefault()).toEpochSecond() }.getOrNull()
        ?.let { Out(it.toString(), "Timestamp") }
}

@Composable
fun B64Tool() = Page("Base64", "Kódovanie a dekódovanie Base64.") {
    var t by rememberSaveable { mutableStateOf("") }
    Field(t, { t = it }, "Text", lines = 3)
    if (t.isNotEmpty()) {
        Out(Base64.getEncoder().encodeToString(t.toByteArray()), "Zakódované")
        Out(runCatching { String(Base64.getDecoder().decode(t.trim())) }.getOrDefault("Neplatný Base64"), "Dekódované")
    }
}

@Composable
fun UrlTool() = Page("URL encode / decode", "Kódovanie a dekódovanie URL.") {
    var t by rememberSaveable { mutableStateOf("") }
    Field(t, { t = it }, "Text alebo URL", lines = 3)
    if (t.isNotEmpty()) {
        Out(URLEncoder.encode(t, "UTF-8").replace("+", "%20"), "Zakódované")
        Out(runCatching { URLDecoder.decode(t, "UTF-8") }.getOrDefault("Neplatné kódovanie"), "Dekódované")
    }
}

@Composable
fun BaseTool() = Page("Číselné sústavy", "Prevod medzi BIN, OCT, DEC a HEX.") {
    var t by rememberSaveable { mutableStateOf("") }
    var b by rememberSaveable { mutableIntStateOf(10) }
    Field(t, { t = it }, "Číslo")
    Chips(listOf("2", "8", "10", "16"), b.toString()) { b = it.toInt() }
    val n = runCatching { BigInteger(t.trim(), b) }.getOrNull()
    if (n != null) Out("BIN  ${n.toString(2)}\nOCT  ${n.toString(8)}\nDEC  ${n.toString(10)}\nHEX  ${n.toString(16).uppercase()}")
    else if (t.isNotBlank()) Err("Neplatné číslo pre zvolenú sústavu.")
}

@Composable
fun JsonTool() = Page("JSON beautifier", "Formátovanie a validácia JSON.") {
    var t by rememberSaveable { mutableStateOf("") }
    Field(t, { t = it }, "JSON", lines = 6)
    val s = t.trim()
    if (s.isNotEmpty()) {
        val r = runCatching {
            when {
                s.startsWith("{") -> JSONObject(s).toString(2)
                s.startsWith("[") -> JSONArray(s).toString(2)
                else -> error("JSON musí byť objekt alebo pole.")
            }
        }
        r.onSuccess { Out(it, "Formátovaný JSON") }
        r.onFailure { Err("Chyba: ${it.message}") }
    }
}

private fun digest(alg: String, s: String) =
    MessageDigest.getInstance(alg).digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

@Composable
fun HashTool() = Page("Hash", "MD5, SHA-1, SHA-256 a SHA-512 textu.") {
    var t by rememberSaveable { mutableStateOf("") }
    Field(t, { t = it }, "Text", lines = 3)
    if (t.isNotEmpty()) listOf("MD5", "SHA-1", "SHA-256", "SHA-512").forEach { Out(digest(it, t), it) }
}

@Composable
fun UuidTool() = Page("UUID generátor", "Náhodné UUID v4 vytvorené cez kryptografický generátor.") {
    var n by rememberSaveable { mutableStateOf("5") }
    var seed by remember { mutableIntStateOf(0) }
    Field(n, { n = it }, "Počet")
    Act("Generovať") { seed++ }
    val c = (n.toIntOrNull() ?: 1).coerceIn(1, 100)
    Out(remember(seed, c) { List(c) { UUID.randomUUID().toString() }.joinToString("\n") })
}

@Composable
fun PwTool() = Page("Generátor hesiel", "Náhodné heslo cez kryptografický generátor.") {
    var len by remember { mutableFloatStateOf(20f) }
    var up by remember { mutableStateOf(true) }
    var lo by remember { mutableStateOf(true) }
    var di by remember { mutableStateOf(true) }
    var sy by remember { mutableStateOf(true) }
    var seed by remember { mutableIntStateOf(0) }
    Text("Dĺžka: ${len.toInt()}")
    Slider(len, { len = it }, valueRange = 8f..64f)
    Chk("Veľké písmená", up) { up = it }
    Chk("Malé písmená", lo) { lo = it }
    Chk("Čísla", di) { di = it }
    Chk("Symboly", sy) { sy = it }
    Act("Generovať") { seed++ }
    val pool = buildString {
        if (up) append("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
        if (lo) append("abcdefghijklmnopqrstuvwxyz")
        if (di) append("0123456789")
        if (sy) append("!@#\$%^&*()-_=+[]{};:,.?")
    }
    if (pool.isNotEmpty()) {
        val pw = remember(seed, len.toInt(), pool) {
            val r = SecureRandom()
            List(len.toInt()) { pool[r.nextInt(pool.length)] }.joinToString("")
        }
        Out(pw, "Heslo")
    }
}

@Composable
fun CaseTool() = Page("Text a veľkosť písmen", "Prevod na veľké, malé, camelCase, snake_case a ďalšie.") {
    var t by rememberSaveable { mutableStateOf("") }
    Field(t, { t = it }, "Text", lines = 3, mono = false)
    if (t.isNotBlank()) {
        val w = Regex("[^\\p{L}\\p{N}]+|(?<=[a-z])(?=[A-Z])").split(t.trim()).filter { it.isNotEmpty() }.map { it.lowercase() }
        val cap = { x: String -> x.replaceFirstChar { it.uppercase() } }
        Out(t.uppercase(), "VEĽKÉ")
        Out(t.lowercase(), "malé")
        Out(t.split(" ").joinToString(" ") { cap(it.lowercase()) }, "Každé Slovo Veľké")
        Out(w.mapIndexed { i, x -> if (i == 0) x else cap(x) }.joinToString(""), "camelCase")
        Out(w.joinToString("") { cap(it) }, "PascalCase")
        Out(w.joinToString("_"), "snake_case")
        Out(w.joinToString("-"), "kebab-case")
    }
}

@Composable
fun PctTool() = Page("Percentá", "Základné výpočty s percentami.") {
    var a by rememberSaveable { mutableStateOf("") }
    var b by rememberSaveable { mutableStateOf("") }
    Field(a, { a = it }, "A")
    Field(b, { b = it }, "B")
    val x = num(a); val y = num(b)
    if (x != null && y != null) {
        val l = mutableListOf("${a.trim()} % z ${b.trim()} = %.4g".format(x * y / 100))
        if (y != 0.0) l += "${a.trim()} je %.4g %% z ${b.trim()}".format(x / y * 100)
        if (x != 0.0) l += "Zmena z ${a.trim()} na ${b.trim()} = %.4g %%".format((y - x) / x * 100)
        Out(l.joinToString("\n"))
    }
}

@Composable
fun VatTool() = Page("DPH kalkulačka", "Prepočet medzi cenou bez DPH a s DPH.") {
    var a by rememberSaveable { mutableStateOf("100") }
    var r by rememberSaveable { mutableStateOf("23") }
    var gross by rememberSaveable { mutableStateOf(false) }
    Field(a, { a = it }, "Suma")
    Field(r, { r = it }, "Sadzba (%)")
    Chips(listOf("23", "19", "5"), r) { r = it }
    Chips(listOf("Bez DPH", "S DPH"), if (gross) "S DPH" else "Bez DPH") { gross = it == "S DPH" }
    val x = num(a); val p = num(r)
    if (x != null && p != null) {
        val net = if (gross) x / (1 + p / 100) else x
        val g = if (gross) x else x * (1 + p / 100)
        Out("Bez DPH  %.2f\nDPH      %.2f\nS DPH    %.2f".format(net, g - net, g))
    }
}
