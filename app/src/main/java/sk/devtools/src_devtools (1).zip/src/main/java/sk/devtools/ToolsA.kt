@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)

package sk.devtools

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URI
import java.net.URLDecoder
import java.util.Base64
import kotlin.coroutines.cancellation.CancellationException

// ───────────────────────── Dáta a bezpečnosť ─────────────────────────

@Composable
fun JwtTool() = Page("JWT debugger", "Dekóduje hlavičku a payload. Podpis sa neoveruje, token neopúšťa zariadenie.") {
    var t by rememberSaveable { mutableStateOf("") }
    Field(t, { t = it }, "Token", lines = 4)
    if (t.isNotBlank()) {
        val r = remember(t) { runCatching { jwtDecode(t) } }
        r.onSuccess { Out(it.msg, "Info"); Out(it.header, "Header"); Out(it.payload, "Payload"); Out(it.sig, "Signature") }
        r.onFailure { Err(it.message ?: "Chyba.") }
    }
}

@Composable
fun HmacTool() = Page("HMAC", "Podpis správy tajným kľúčom (HMAC) v hex a Base64.") {
    var m by rememberSaveable { mutableStateOf("") }
    var k by rememberSaveable { mutableStateOf("") }
    var a by rememberSaveable { mutableStateOf("SHA-256") }
    Field(m, { m = it }, "Správa", lines = 4)
    Field(k, { k = it }, "Tajný kľúč")
    Chips(listOf("SHA-256", "SHA-384", "SHA-512", "SHA-1"), a) { a = it }
    if (k.isNotEmpty()) {
        val r = remember(m, k, a) { runCatching { hmacOf(a, k, m) } }
        r.onSuccess { Out(it.first, "Hex"); Out(it.second, "Base64") }
        r.onFailure { Err("Výpočet zlyhal: ${it.message}") }
    } else Err("Zadaj tajný kľúč.")
}

@Composable
fun JpathTool() = Page("JSONPath dotaz", "Vyhľadávanie v JSON-e. Podporuje \$.a.b, [0], [*], .*, ['kľúč'] a ..kľúč.") {
    var j by rememberSaveable { mutableStateOf("") }
    var p by rememberSaveable { mutableStateOf("\$.users[*].name") }
    Field(j, { j = it }, "JSON", lines = 7)
    Field(p, { p = it }, "Cesta")
    if (j.isNotBlank()) {
        val r = remember(j, p) { runCatching { jsonPath(Js.parse(j.trim()), p) } }
        r.onSuccess { Out(it.first, "Nájdených: ${it.second}") }
        r.onFailure { Err("Chyba: ${it.message}") }
    }
}

// ───────────────────────── Konvertory ─────────────────────────

@Composable
fun CsvTool() = Page("JSON ⇄ CSV", "Prevod poľa objektov na CSV a naopak.") {
    var t by rememberSaveable { mutableStateOf("") }
    var m by rememberSaveable { mutableStateOf("JSON → CSV") }
    Chips(listOf("JSON → CSV", "CSV → JSON"), m) { m = it }
    Field(t, { t = it }, "Vstup", lines = 8)
    if (t.isNotBlank()) {
        val r = remember(t, m) { runCatching { if (m == "JSON → CSV") jsonToCsv(t) else csvToJson(t) } }
        r.onSuccess { Out(it.second, "Info"); Out(it.first, "Výstup") }
        r.onFailure { Err(if (m == "JSON → CSV") "Neplatný JSON: ${it.message}" else it.message ?: "Chyba.") }
    }
}

@Composable
fun EntTool() = Page("HTML entity", "Kódovanie a dekódovanie znakov ako &amp; a &lt;.") {
    var t by rememberSaveable { mutableStateOf("") }
    Field(t, { t = it }, "Vstup", lines = 4)
    if (t.isNotEmpty()) {
        Out(htmlEncode(t), "Zakódované")
        Out(htmlDecode(t), "Dekódované")
    }
}

@Composable
fun EscTool() = Page("Escape reťazcov", "Escape a unescape pre JSON a JavaScript reťazce, vrátane sekvencií \\uXXXX.") {
    var t by rememberSaveable { mutableStateOf("") }
    var op by rememberSaveable { mutableStateOf(ESC_OPS[0].first) }
    Field(t, { t = it }, "Vstup", lines = 4)
    Chips(ESC_OPS.map { it.first }, op) { op = it }
    if (t.isNotEmpty()) {
        val r = remember(t, op) { runCatching { ESC_OPS.first { it.first == op }.second(t) } }
        r.onSuccess { Out(it, "Výstup") }
        r.onFailure { Err("Vstup sa nepodarilo spracovať.") }
    }
}

@Composable
fun HexbTool() = Page("Text ⇄ Hex / Binárne", "Prevod textu (UTF-8) na hexadecimálny alebo binárny zápis a späť.") {
    var t by rememberSaveable { mutableStateOf("") }
    var op by rememberSaveable { mutableStateOf(HEX_OPS[0].first) }
    Field(t, { t = it }, "Vstup", lines = 4)
    Chips(HEX_OPS.map { it.first }, op) { op = it }
    if (t.isNotEmpty()) {
        val r = remember(t, op) { runCatching { HEX_OPS.first { it.first == op }.second(t) } }
        r.onSuccess { Out(it, "Výstup") }
        r.onFailure { Err("Vstup má neplatný formát pre túto operáciu.") }
    }
}

@Composable
fun UnitsTool() = Page("Prevod jednotiek", "Dĺžka, hmotnosť, dáta, čas a teplota.") {
    var c by rememberSaveable { mutableStateOf("Dĺžka") }
    var u by rememberSaveable { mutableStateOf("m") }
    var v by rememberSaveable { mutableStateOf("1") }
    Chips(UNITS.keys.toList(), c) { c = it; u = UNITS.getValue(it).keys.first() }
    Field(v, { v = it }, "Hodnota")
    val units = UNITS.getValue(c).keys.toList()
    Chips(units, if (u in units) u else units.first()) { u = it }
    val x = v.trim().replace(',', '.').toDoubleOrNull()
    if (x != null) Out(unitReport(c, if (u in units) u else units.first(), x))
}

@Composable
fun RemTool() = Page("px ↔ rem", "Prevod CSS jednotiek podľa základnej veľkosti písma.") {
    var b by rememberSaveable { mutableStateOf("16") }
    var px by rememberSaveable { mutableStateOf("16") }
    var rem by rememberSaveable { mutableStateOf("1") }
    val base = b.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it > 0 } ?: 16.0
    fun f(d: Double) = Js.fmt((Math.round(d * 10000) / 10000.0))
    Field(b, { b = it }, "Základ (px)")
    Field(px, { px = it; rem = it.trim().replace(',', '.').toDoubleOrNull()?.let { p -> f(p / base) } ?: "" }, "px")
    Field(rem, { rem = it; px = it.trim().replace(',', '.').toDoubleOrNull()?.let { r -> f(r * base) } ?: "" }, "rem")
    Out(listOf(10, 12, 14, 16, 18, 20, 24, 28, 32, 40, 48, 64).joinToString("\n") { "$it px".padEnd(10) + f(it / base) + " rem" }, "Tabuľka")
}

@Composable
fun TsgenTool() = Page("JSON → TypeScript", "Z JSON-u vygeneruje TypeScript rozhranie.") {
    var t by rememberSaveable { mutableStateOf("") }
    var n by rememberSaveable { mutableStateOf("Root") }
    Field(t, { t = it }, "JSON", lines = 7)
    Field(n, { n = it }, "Názov typu")
    if (t.isNotBlank()) {
        val r = remember(t, n) { runCatching { jsonToTs(t.trim(), n) } }
        r.onSuccess { Out(it, "TypeScript") }
        r.onFailure { Err("Neplatný JSON: ${it.message}") }
    }
}

@Composable
fun YamlTool() = Page("YAML ⇄ JSON", "Prevod medzi YAML a JSON. Podporuje mapy, zoznamy, blokové texty a základné inline zápisy, nie kotvy a tagy.") {
    var t by rememberSaveable { mutableStateOf("") }
    var m by rememberSaveable { mutableStateOf("YAML → JSON") }
    Chips(listOf("YAML → JSON", "JSON → YAML"), m) { m = it }
    Field(t, { t = it }, "Vstup", lines = 8)
    if (t.isNotBlank()) {
        val r = remember(t, m) { runCatching { if (m == "YAML → JSON") Js.stringify(Yml.parse(t), 2) else Yml.dump(Js.parse(t.trim())) } }
        r.onSuccess { Out(it, "Výstup") }
        r.onFailure { Err(if (m == "YAML → JSON") "Chyba YAML: ${it.message}" else "Neplatný JSON: ${it.message}") }
    }
}

@Composable
fun QstrTool() = Page("Query string ⇄ JSON", "Prevod parametrov URL na JSON a naopak. Opakované kľúče sa zlúčia do poľa.") {
    var t by rememberSaveable { mutableStateOf("") }
    var m by rememberSaveable { mutableStateOf("Query → JSON") }
    Chips(listOf("Query → JSON", "JSON → Query"), m) { m = it }
    Field(t, { t = it }, "Vstup", lines = 4)
    if (t.isNotBlank()) {
        val r = remember(t, m) { runCatching { if (m == "Query → JSON") queryToJson(t) else jsonToQuery(t.trim()) } }
        r.onSuccess { Out(it, "Výstup") }
        r.onFailure { Err("Neplatný JSON: ${it.message}") }
    }
}

class ImgData(val info: String, val uri: String, val b64: String, val bmp: ImageBitmap?)

private fun loadImg(ctx: Context, uri: Uri): ImgData {
    val cr = ctx.contentResolver
    val bytes = cr.openInputStream(uri)?.use { it.readBytes() } ?: throw Exception("Súbor sa nepodarilo otvoriť.")
    if (bytes.size > 8 * 1024 * 1024) throw Exception("Obrázok je príliš veľký (limit 8 MB).")
    val mime = cr.getType(uri) ?: "application/octet-stream"
    val name = runCatching {
        cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    }.getOrNull() ?: "obrázok"
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
    var s = 1
    while (o.outWidth / (s * 2) >= 1024 || o.outHeight / (s * 2) >= 1024) s *= 2
    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })?.asImageBitmap()
    val b64 = Base64.getEncoder().encodeToString(bytes)
    val full = "data:$mime;base64,$b64"
    return ImgData("$name, $mime, ${"%.1f".format(java.util.Locale.ROOT, bytes.size / 1024.0)} kB, v Base64 ${"%.1f".format(java.util.Locale.ROOT, full.length / 1024.0)} kB", full, b64, bmp)
}

@Composable
fun ImgTool() = Page("Obrázok → Base64", "Prevod obrázka na data URI alebo čistý Base64. Súbor neopúšťa zariadenie.") {
    val ctx = LocalContext.current
    val sc = rememberCoroutineScope()
    var d by remember { mutableStateOf<ImgData?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            busy = true; err = null
            sc.launch {
                try { d = withContext(Dispatchers.IO) { loadImg(ctx, uri) } }
                catch (e: CancellationException) { throw e }
                catch (e: Exception) { err = e.message ?: "Nastala chyba."; d = null }
                busy = false
            }
        }
    }
    Act(if (busy) "Načítavam…" else "Vybrať obrázok") { if (!busy) pick.launch("image/*") }
    err?.let { Err(it) }
    d?.let { x ->
        Out(x.info, "Súbor")
        x.bmp?.let { Image(it, null, Modifier.fillMaxWidth().heightIn(max = 240.dp).clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.Fit) }
        fun cut(s: String) = if (s.length > 1500) s.take(1500) + "…" else s
        Out(cut(x.uri), "Data URI", copy = x.uri)
        Out(cut(x.b64), "Čistý Base64", copy = x.b64)
    }
}

// ───────────────────────── Text ─────────────────────────

@Composable
fun RxTool() = Page("Regex tester", "Vyskúšaj regulárny výraz a zvýrazni zhody v texte (syntax Java/Kotlin). Flagy: i, m, s.") {
    var p by rememberSaveable { mutableStateOf("") }
    var f by rememberSaveable { mutableStateOf("") }
    var t by rememberSaveable { mutableStateOf("") }
    Field(p, { p = it }, "Výraz")
    Field(f, { f = it }, "Flagy")
    Field(t, { t = it }, "Text", lines = 5)
    val hl = MaterialTheme.colorScheme.primaryContainer
    if (p.isNotEmpty()) {
        val r = remember(p, f, t) {
            runCatching {
                val o = mutableSetOf<RegexOption>()
                if ('i' in f) o.add(RegexOption.IGNORE_CASE)
                if ('m' in f) o.add(RegexOption.MULTILINE)
                if ('s' in f) o.add(RegexOption.DOT_MATCHES_ALL)
                Regex(p, o).findAll(t).take(2000).toList()
            }
        }
        r.onSuccess { ms ->
            val a = buildAnnotatedString {
                var last = 0
                for (m in ms) {
                    append(t.substring(last, m.range.first))
                    withStyle(SpanStyle(background = hl)) { append(m.value) }
                    last = m.range.last + 1
                }
                append(t.substring(last))
            }
            RichOut(a, "Zhody: ${ms.size}")
            val g = ms.withIndex().filter { it.value.groupValues.size > 1 }.joinToString("\n") { (i, m) ->
                "#${i + 1}: " + m.groups.drop(1).joinToString(", ") { x -> x?.value?.let { v -> Js.quote(v) } ?: "—" }
            }
            if (g.isNotEmpty()) Out(g, "Skupiny")
        }
        r.onFailure { Err(it.message ?: "Neplatný výraz.") }
    }
}

@Composable
fun DiffTool() = Page("Porovnanie textov", "Riadkový diff dvoch textov.") {
    var a by rememberSaveable { mutableStateOf("") }
    var b by rememberSaveable { mutableStateOf("") }
    Field(a, { a = it }, "Pôvodný", lines = 5)
    Field(b, { b = it }, "Nový", lines = 5)
    val add = Color(0x442E7D32)
    val del = Color(0x44C62828)
    val r = remember(a, b) { runCatching { diffLines(a, b) } }
    r.onSuccess { (lines, ad, de) ->
        Out(if (ad > 0 || de > 0) "Pridané: $ad, odstránené: $de" else "Texty sú rovnaké.", "Zhrnutie")
        val an = buildAnnotatedString {
            lines.forEachIndexed { i, l ->
                if (i > 0) append("\n")
                when (l.kind) {
                    '+' -> withStyle(SpanStyle(background = add)) { append("+ " + l.text) }
                    '-' -> withStyle(SpanStyle(background = del)) { append("- " + l.text) }
                    else -> append("  " + l.text)
                }
            }
        }
        RichOut(an, "Rozdiely")
    }
    r.onFailure { Err(it.message ?: "Chyba.") }
}

@Composable
fun LinesTool() = Page("Úprava riadkov", "Zoradenie, odstránenie duplicít a ďalšie úpravy zoznamu riadkov.") {
    var t by rememberSaveable { mutableStateOf("") }
    var op by rememberSaveable { mutableStateOf("") }
    Field(t, { t = it }, "Vstup (jeden záznam na riadok)", lines = 8)
    Chips(LINE_OPS.map { it.first }, op) { op = it }
    if (op.isNotEmpty() && t.isNotEmpty()) {
        val a = t.split("\n")
        val r = LINE_OPS.first { it.first == op }.second(a)
        Out("Riadkov: ${a.size} → ${r.size}", "Info")
        Out(r.joinToString("\n"), "Výstup")
    }
}

@Composable
fun MdTool() = Page("Markdown náhľad", "Základný Markdown s živým náhľadom: nadpisy, zoznamy, kód, citácie a odkazy.") {
    var t by rememberSaveable { mutableStateOf("## Ukážka\n\nToto je **tučný** text, *kurzíva* a `kód`.\n\n- prvá položka\n- druhá položka\n\n> Citácia\n\n[Odkaz](https://example.com)") }
    Field(t, { t = it }, "Markdown", lines = 8)
    Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) { MarkdownView(t) }
    }
}

@Composable
fun SlugTool() = Page("Slug generátor", "Z textu vytvorí URL-friendly reťazec bez diakritiky.") {
    var t by rememberSaveable { mutableStateOf("Čo je nové v Bratislave? Máj 2026") }
    var s by rememberSaveable { mutableStateOf("-") }
    Field(t, { t = it }, "Text", mono = false)
    Chips(listOf("-", "_"), s) { s = it }
    Out(slugOf(t, s), "Slug")
}

@Composable
fun UniTool() = Page("Unicode inšpektor", "Kódové body, UTF-8 bajty a UTF-16 jednotky každého znaku.") {
    var t by rememberSaveable { mutableStateOf("Čaj ☕ 😀") }
    Field(t, { t = it }, "Text", mono = false)
    if (t.isNotEmpty()) {
        val (lines, info) = remember(t) { unicodeReport(t) }
        Out(info, "Súhrn")
        Out(lines, "Znaky")
    }
}

@Composable
fun TstatTool() = Page("Štatistika textu", "Počet znakov, slov, viet, čas čítania a najčastejšie slová.") {
    var t by rememberSaveable { mutableStateOf("") }
    Field(t, { t = it }, "Vlož alebo napíš text…", lines = 8, mono = false)
    Out(remember(t) { textStats(t) })
}

@Composable
fun LoremTool() = Page("Lorem ipsum", "Generátor výplňového textu po odsekoch, vetách alebo slovách.") {
    var n by rememberSaveable { mutableStateOf("3") }
    var u by rememberSaveable { mutableStateOf("Odseky") }
    var c by rememberSaveable { mutableStateOf(true) }
    var seed by remember { mutableIntStateOf(0) }
    Field(n, { n = it }, "Počet")
    Chips(listOf("Odseky", "Vety", "Slová"), u) { u = it }
    Chk("Začať „Lorem ipsum dolor sit amet“", c) { c = it }
    Act("Generovať") { seed++ }
    Out(remember(n, u, c, seed) { lorem(when (u) { "Odseky" -> "p"; "Vety" -> "s"; else -> "w" }, n.trim().toIntOrNull() ?: 1, c) })
}

@Composable
fun CipherTool() = Page("Šifry a morseovka", "Caesarova šifra, ROT13, Atbash a morseovka. Výsledok sa aktualizuje priebežne.") {
    var t by rememberSaveable { mutableStateOf("") }
    var m by rememberSaveable { mutableStateOf("Caesar") }
    var k by rememberSaveable { mutableStateOf("3") }
    Field(t, { t = it }, "Text…", lines = 3, mono = false)
    Chips(CIPHERS, m) { m = it }
    if (m == "Caesar") Field(k, { k = it }, "Posun")
    if (t.isNotEmpty()) Out(cipher(m, t, k.trim().toIntOrNull() ?: 0))
}

// ───────────────────────── Dizajn a web ─────────────────────────

@Composable
fun CssTool() = Page("CSS minifikátor", "Minifikácia a formátovanie CSS. Medzery v reťazcoch sa pri minifikácii zlúčia.") {
    var t by rememberSaveable { mutableStateOf("") }
    var m by rememberSaveable { mutableStateOf("Minifikovať") }
    Chips(listOf("Minifikovať", "Formátovať"), m) { m = it }
    Field(t, { t = it }, "a { color: red; }", lines = 8)
    if (t.isNotBlank()) Out(remember(t, m) { if (m == "Minifikovať") cssMin(t) else cssFormat(t) })
}

@Composable
fun UrlpTool() = Page("Analýza URL", "Rozloží adresu na časti a vypíše query parametre.") {
    var t by rememberSaveable { mutableStateOf("") }
    Field(t, { t = it }, "https://example.com:8080/cesta?a=1&b=dva#cast")
    if (t.isNotBlank()) {
        val r = remember(t) {
            runCatching {
                val u = URI(t.trim())
                if (u.scheme == null || (u.host == null && u.authority == null)) throw Exception("x")
                val user = u.userInfo?.substringBefore(':')
                val base = listOf(
                    "Protokol" to u.scheme + ":", "Hostiteľ" to (u.host ?: u.authority), "Port" to (if (u.port >= 0) u.port.toString() else "(predvolený)"),
                    "Cesta" to u.rawPath.orEmpty().ifEmpty { "/" }, "Hash" to (u.rawFragment?.let { "#$it" } ?: "—"),
                    "Pôvod" to u.scheme + "://" + (u.host ?: u.authority) + (if (u.port >= 0) ":${u.port}" else ""), "Používateľ" to (user ?: "—")
                ).joinToString("\n") { it.first.padEnd(12) + it.second }
                val ps = u.rawQuery?.split('&')?.filter { it.isNotEmpty() }?.map {
                    val i = it.indexOf('=')
                    URLDecoder.decode(if (i < 0) it else it.substring(0, i), "UTF-8") to URLDecoder.decode(if (i < 0) "" else it.substring(i + 1), "UTF-8")
                } ?: emptyList()
                base + "\n\nParametre (${ps.size})\n" + (if (ps.isEmpty()) "  —" else ps.joinToString("\n") { "  ${it.first} = ${it.second}" })
            }
        }
        r.onSuccess { Out(it, "Platná URL") }
        r.onFailure { Err("Neplatná URL. Zadaj ju aj s protokolom, napríklad https://.") }
    }
}

@Composable
fun HttpTool() = Page("HTTP stavové kódy", "Prehľad najpoužívanejších kódov. Hľadaj podľa čísla alebo názvu.") {
    var q by rememberSaveable { mutableStateOf("") }
    Field(q, { q = it }, "404, redirect, timeout…", mono = false)
    Out(remember(q) { httpCodesReport(q) })
}

@Composable
fun ChmodTool() = Page("chmod kalkulačka", "Unixové oprávnenia súborov v osmičkovom aj symbolickom zápise.") {
    var oct by rememberSaveable { mutableStateOf("755") }
    val valid = Regex("^[0-7]{3}$").matches(oct)
    val perm = if (valid) oct.toInt(8) else 0
    val who = listOf("Vlastník", "Skupina", "Ostatní")
    val what = listOf("čítanie (r)" to 4, "zápis (w)" to 2, "spúšťanie (x)" to 1)
    fun toggle(i: Int, bit: Int) { oct = "%03o".format(perm xor (bit shl (6 - 3 * i))) }
    who.forEachIndexed { i, w ->
        Column {
            Lbl(w)
            what.forEach { (n, bit) -> Chk(n, perm and (bit shl (6 - 3 * i)) != 0) { toggle(i, bit) } }
        }
    }
    Field(oct, { oct = it.filter { c -> c.isDigit() }.take(3) }, "Osmičkovo")
    if (valid) {
        val sym = (0..2).joinToString("") { i ->
            val d = (perm shr (6 - 3 * i)) and 7
            (if (d and 4 != 0) "r" else "-") + (if (d and 2 != 0) "w" else "-") + (if (d and 1 != 0) "x" else "-")
        }
        Out(sym, "Symbolicky")
        Out("chmod $oct subor", "Príkaz")
    } else Err("Zadaj tri osmičkové číslice (0–7).")
}

@Composable
fun CronTool() = Page("Cron výrazy", "Overenie 5-poľového cron výrazu a najbližšie spustenia.") {
    var e by rememberSaveable { mutableStateOf("*/15 9-17 * * 1-5") }
    Field(e, { e = it }, "minúta hodina deň mesiac deň-v-týždni")
    val r = remember(e) { runCatching { cronNext(e).joinToString("\n").ifEmpty { "V najbližšom roku sa nespustí." } } }
    Res(r, "Najbližšie spustenia (lokálny čas)")
}

@Composable
fun TzTool() = Page("Časové pásma", "Prevod dátumu a času z jedného pásma do viacerých ďalších.") {
    var d by rememberSaveable { mutableStateOf(java.time.LocalDateTime.now().withNano(0).toString()) }
    var z by rememberSaveable { mutableStateOf(java.time.ZoneId.systemDefault().id) }
    Field(d, { d = it }, "Dátum a čas (2024-01-31T14:30:00)")
    Field(z, { z = it }, "Zdrojové pásmo (napr. Europe/Prague)")
    Chips(TZ_LIST, z) { z = it }
    Res(remember(d, z) { runCatching { tzReport(d, z) } })
}

@Composable
fun DdTool() = Page("Rozdiel dátumov", "Koľko času uplynulo medzi dvoma dátumami.") {
    var a by rememberSaveable { mutableStateOf(java.time.LocalDateTime.now().withNano(0).toString()) }
    var b by rememberSaveable { mutableStateOf(java.time.LocalDateTime.now().withNano(0).plusDays(7).toString()) }
    Field(a, { a = it }, "Od (2024-01-31T14:30:00)")
    Field(b, { b = it }, "Do")
    Res(remember(a, b) { runCatching { dateDiff(a, b) } })
}

@Composable
fun AspectTool() = Page("Pomer strán", "Zjednodušený pomer strán a prepočet rozmerov so zachovaním proporcií.") {
    var w by rememberSaveable { mutableStateOf("1920") }
    var h by rememberSaveable { mutableStateOf("1080") }
    var nw by rememberSaveable { mutableStateOf("1280") }
    var nh by rememberSaveable { mutableStateOf("720") }
    fun n(s: String) = s.trim().replace(',', '.').toDoubleOrNull()
    fun f(d: Double) = Js.fmt(Math.round(d * 100) / 100.0)
    Rw {
        Box(Modifier.weight(1f)) { Field(w, { w = it; val a = n(w); val b = n(h); val c = n(nw); if (a != null && b != null && a > 0 && b > 0 && c != null && c > 0) nh = f(c * b / a) }, "Šírka") }
        Box(Modifier.weight(1f)) { Field(h, { h = it; val a = n(w); val b = n(h); val c = n(nw); if (a != null && b != null && a > 0 && b > 0 && c != null && c > 0) nh = f(c * b / a) }, "Výška") }
    }
    val a = n(w); val b = n(h)
    if (a != null && b != null && a > 0 && b > 0) {
        val g = if (a % 1.0 == 0.0 && b % 1.0 == 0.0) java.math.BigInteger.valueOf(a.toLong()).gcd(java.math.BigInteger.valueOf(b.toLong())).toDouble() else 1.0
        Out("Pomer      ${Js.fmt(a / g)}:${Js.fmt(b / g)}\nDecimálne  ${Js.fmt(Math.round(a / b * 10000) / 10000.0)}")
        Rw {
            Box(Modifier.weight(1f)) { Field(nw, { nw = it; val c = n(it); nh = if (c != null && c > 0) f(c * b / a) else "" }, "Nová šírka") }
            Box(Modifier.weight(1f)) { Field(nh, { nh = it; val c = n(it); nw = if (c != null && c > 0) f(c * a / b) else "" }, "Nová výška") }
        }
    } else Err("Zadaj kladné rozmery.")
}

// ───────────────────────── Kalkulačky ─────────────────────────

@Composable
fun RandTool() = Page("Náhodné hodnoty", "Náhodné čísla, hod kockou a mincou alebo výber z vlastného zoznamu.") {
    var a by rememberSaveable { mutableStateOf("1") }
    var b by rememberSaveable { mutableStateOf("100") }
    var c by rememberSaveable { mutableStateOf("1") }
    var l by rememberSaveable { mutableStateOf("") }
    var out by remember { mutableStateOf("") }
    Rw {
        Box(Modifier.weight(1f)) { Field(a, { a = it }, "Od") }
        Box(Modifier.weight(1f)) { Field(b, { b = it }, "Do") }
        Box(Modifier.weight(1f)) { Field(c, { c = it }, "Počet") }
    }
    Act("Náhodné čísla") {
        val x = a.trim().toLongOrNull(); val y = b.trim().toLongOrNull(); val n = (c.trim().toIntOrNull() ?: 1).coerceIn(1, 100)
        out = if (x == null || y == null || y < x || y - x > 4_000_000_000L) "Zadaj platný rozsah (od ≤ do)."
        else List(n) { x + (rng.nextDouble() * (y - x + 1)).toLong().coerceAtMost(y - x) }.joinToString(", ")
    }
    Rw {
        Btn("Kocka (D6)", Modifier.weight(1f)) { out = "Kocka: " + (1 + rng.nextInt(6)) }
        Btn("Minca", Modifier.weight(1f)) { out = if (rng.nextBoolean()) "Hlava" else "Znak" }
    }
    Field(l, { l = it }, "Zoznam na výber (jeden záznam na riadok)", lines = 4, mono = false)
    Act("Vybrať náhodný") {
        val items = l.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        out = if (items.isEmpty()) "Zadaj aspoň jeden riadok." else items[rng.nextInt(items.size)]
    }
    if (out.isNotEmpty()) Out(out)
}
