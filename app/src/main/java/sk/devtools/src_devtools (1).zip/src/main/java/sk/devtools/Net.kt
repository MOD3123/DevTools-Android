package sk.devtools

// Natívne sieťové nástroje (bez Cloudflare Workera). Všetky funkcie sú blokujúce – volaj ich z Dispatchers.IO.

import java.io.ByteArrayOutputStream
import java.math.BigInteger
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.IDN
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.security.AlgorithmParameters
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.ECParameterSpec
import java.security.spec.ECPoint
import java.security.spec.ECPublicKeySpec
import java.security.spec.MGF1ParameterSpec
import java.security.spec.PSSParameterSpec
import java.security.spec.RSAPublicKeySpec
import java.time.Instant
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Base64
import java.util.Locale
import java.util.concurrent.Callable
import java.util.concurrent.Executors

class Resp(
    val url: String, val status: Int, val statusText: String, val headers: List<Pair<String, String>>,
    val body: ByteArray?, val truncated: Boolean, val contentType: String, val totalMs: Long,
    val hops: List<Hop>, val error: String?
) {
    val text: String
        get() {
            val cs = Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE).find(contentType)?.groupValues?.get(1)
            val charset = runCatching { charset(cs ?: "UTF-8") }.getOrDefault(Charsets.UTF_8)
            return String(body ?: ByteArray(0), charset)
        }
    val isBinary: Boolean
        get() {
            val t = contentType.lowercase()
            return t.startsWith("image/") || t.startsWith("audio/") || t.startsWith("video/") || t.startsWith("font/") ||
                t.contains("octet-stream") || t.contains("pdf") || t.contains("zip") || t.contains("gzip")
        }
    fun header(name: String): String? = headers.filter { it.first.equals(name, true) }.joinToString(", ") { it.second }.ifEmpty { null }
}

private val REDIRECTS = setOf(301, 302, 303, 307, 308)

fun httpFetch(
    url0: String, method: String = "GET", headers: List<Pair<String, String>> = emptyList(), body: String? = null,
    basic: Pair<String, String>? = null, follow: Boolean = true, readBody: Boolean = true,
    maxBody: Int = 1_500_000, maxHops: Int = 10, timeoutMs: Int = 15000
): Resp {
    var url = normalizeUrl(url0)
    var m = method.uppercase()
    var b = body
    val hops = mutableListOf<Hop>()
    val t00 = System.nanoTime()
    var i = 1
    while (true) {
        var c: HttpURLConnection? = null
        try {
            c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.requestMethod = m
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.setRequestProperty("User-Agent", "DevTools/1.0")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (basic != null) c.setRequestProperty("Authorization", "Basic " + Base64.getEncoder().encodeToString("${basic.first}:${basic.second}".toByteArray()))
            if (!b.isNullOrEmpty() && m != "GET" && m != "HEAD") {
                c.doOutput = true
                c.outputStream.use { it.write(b!!.toByteArray()) }
            }
            val t0 = System.nanoTime()
            val code = c.responseCode
            val ms = (System.nanoTime() - t0) / 1_000_000
            val loc = c.getHeaderField("Location")
            hops += Hop(i, url, code, c.responseMessage ?: "", ms, loc, null)
            val hs = c.headerFields.entries.filter { it.key != null }.flatMap { e -> e.value.map { e.key to it } }
            if (follow && code in REDIRECTS && !loc.isNullOrBlank()) {
                if (i > maxHops) {
                    hops += Hop(i + 1, url, 0, "", 0, null, "Príliš veľa presmerovaní (limit $maxHops).")
                    return Resp(url, code, c.responseMessage ?: "", hs, null, false, "", (System.nanoTime() - t00) / 1_000_000, hops, "Príliš veľa presmerovaní (limit $maxHops).")
                }
                url = URL(URL(url), loc).toString()
                if (code != 307 && code != 308 && m != "HEAD") { m = "GET"; b = null }
                i++
                continue
            }
            var data: ByteArray? = null
            var trunc = false
            if (readBody && m != "HEAD") {
                val st = if (code >= 400) c.errorStream else c.inputStream
                if (st != null) {
                    val o = ByteArrayOutputStream()
                    val buf = ByteArray(8192)
                    st.use { s ->
                        while (true) {
                            val n = s.read(buf)
                            if (n < 0) break
                            if (o.size() + n > maxBody) { o.write(buf, 0, maxBody - o.size()); trunc = true; break }
                            o.write(buf, 0, n)
                        }
                    }
                    data = o.toByteArray()
                }
            }
            return Resp(url, code, c.responseMessage ?: "", hs, data, trunc, c.contentType ?: "", (System.nanoTime() - t00) / 1_000_000, hops, null)
        } catch (e: Exception) {
            val msg = e.message ?: e.javaClass.simpleName
            hops += Hop(i, url, 0, "", 0, null, msg)
            return Resp(url, 0, "", emptyList(), null, false, "", (System.nanoTime() - t00) / 1_000_000, hops, msg)
        } finally {
            c?.disconnect()
        }
    }
}

fun Resp.report(): String {
    val sb = StringBuilder()
    if (error != null) {
        if (hops.size > 1) sb.append(hops.render()).append("\n\n")
        return sb.append("Chyba: ").append(error).toString()
    }
    val kb = body?.let { if (it.size > 1024) "%.1f kB".format(Locale.ROOT, it.size / 1024.0) else "${it.size} B" }
    sb.append("HTTP $status $statusText  ·  $totalMs ms").append(if (kb != null) "  ·  $kb" else "")
    if (hops.size > 1) sb.append("  ·  presmerovaní: ${hops.size - 1}")
    if (hops.size > 1) sb.append("\n\n").append(hops.render())
    sb.append("\n\nHlavičky odpovede\n").append(headers.joinToString("\n") { it.first + ": " + it.second })
    if (body != null) {
        sb.append("\n\nTelo odpovede\n")
        if (isBinary) sb.append("[binárny obsah: ${contentType.ifEmpty { "?" }}, ${body.size} B]")
        else {
            var t = text
            if (contentType.contains("json", true)) runCatching { t = Js.stringify(Js.parse(t), 2) }
            sb.append(t)
        }
        if (truncated) sb.append("\n… (skrátené)")
    }
    return sb.toString()
}

// ───────────────────────── Bezpečnostné hlavičky ─────────────────────────

private class Lines {
    val l = mutableListOf<String>()
    fun ok(t: String) { l.add("✓ $t") }
    fun wa(t: String) { l.add("! $t") }
    fun bad(t: String) { l.add("✗ $t") }
}

private val SEC = listOf(
    Triple("strict-transport-security", "HSTS", "Pridaj Strict-Transport-Security: max-age=31536000; includeSubDomains."),
    Triple("content-security-policy", "Content-Security-Policy", "Nastav CSP proti XSS."),
    Triple("x-content-type-options", "X-Content-Type-Options", "Pridaj hodnotu nosniff."),
    Triple("x-frame-options", "X-Frame-Options", "Pridaj DENY alebo SAMEORIGIN (alebo CSP frame-ancestors)."),
    Triple("referrer-policy", "Referrer-Policy", "Pridaj napr. strict-origin-when-cross-origin."),
    Triple("permissions-policy", "Permissions-Policy", "Obmedz funkcie prehliadača (kamera, poloha…).")
)

fun securityHeaders(url: String): String {
    val r = httpFetch(url, readBody = false)
    if (r.error != null) throw Exception(r.error)
    val h = r.headers.groupBy({ it.first.lowercase() }, { it.second }).mapValues { it.value.joinToString(", ") }
    val L = Lines()
    var n = 0; var tot = 0
    for ((k, t, adv) in SEC) {
        if (k == "strict-transport-security" && !r.url.startsWith("https:")) { L.wa("HSTS: stránka nejde cez HTTPS."); continue }
        tot++
        var has = h.containsKey(k)
        if (k == "x-frame-options" && !has && Regex("frame-ancestors", RegexOption.IGNORE_CASE).containsMatchIn(h["content-security-policy"] ?: "")) has = true
        if (has) { n++; L.ok(t + ": " + (h[k] ?: "(cez CSP frame-ancestors)").take(100)) } else L.bad("$t: chýba. $adv")
    }
    listOf("server", "x-powered-by").forEach { k -> h[k]?.let { if (it.any(Char::isDigit)) L.wa("Hlavička $k prezrádza verziu: $it") } }
    return "${r.url} (HTTP ${r.status})\nSkóre: $n z $tot\n\n" + L.l.joinToString("\n")
}

// ───────────────────────── Analýza stránky ─────────────────────────

private val ATTR = Regex("""([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+))""")
private fun attrs(tag: String): Map<String, String> {
    val m = LinkedHashMap<String, String>()
    ATTR.findAll(tag).forEach { a -> m[a.groupValues[1].lowercase()] = htmlDecode(a.groups[2]?.value ?: a.groups[3]?.value ?: a.groups[4]?.value ?: "") }
    // atribúty bez hodnoty (napr. alt) zachytíme len ako prítomnosť
    Regex("""\s([a-zA-Z_:][-a-zA-Z0-9_:.]*)(?=\s|/?>|$)""").findAll(ATTR.replace(tag, " ")).forEach { a -> m.putIfAbsent(a.groupValues[1].lowercase(), "") }
    return m
}

fun pageAnalysis(url: String): String {
    val r = httpFetch(url)
    if (r.error != null) throw Exception(r.error)
    if (r.body == null || r.isBinary) throw Exception("Odpoveď nie je HTML.")
    val html = r.text
    val L = Lines()
    val metas = Regex("<meta\\s[^>]*>", RegexOption.IGNORE_CASE).findAll(html).map { attrs(it.value) }.toList()
    fun meta(n: String) = metas.firstOrNull { it["name"]?.equals(n, true) == true }?.get("content")?.trim()?.ifEmpty { null }
    fun prop(n: String) = metas.firstOrNull { it["property"] == n }?.get("content")?.trim()?.ifEmpty { null }
    val links = Regex("<link\\s[^>]*>", RegexOption.IGNORE_CASE).findAll(html).map { attrs(it.value) }.toList()

    val title = Regex("<title[^>]*>([\\s\\S]*?)</title>", RegexOption.IGNORE_CASE).find(html)?.groupValues?.get(1)
        ?.let { htmlDecode(it).replace(Regex("\\s+"), " ").trim() } ?: ""
    if (title.isEmpty()) L.bad("Chýba title.") else if (title.length > 60) L.wa("Title má ${title.length} znakov (odporúčané do 60): $title") else L.ok("Title (${title.length}): $title")
    val ds = meta("description")
    if (ds == null) L.bad("Chýba meta description.") else if (ds.length > 160 || ds.length < 50) L.wa("Description má ${ds.length} znakov (odporúčané 50 až 160).") else L.ok("Description (${ds.length} znakov).")
    val cn = links.firstOrNull { (it["rel"] ?: "").split(Regex("\\s+")).any { x -> x.equals("canonical", true) } }?.get("href")
    if (cn != null) L.ok("Canonical: $cn") else L.wa("Chýba canonical.")
    val rb = meta("robots")
    if (rb != null && rb.contains("noindex", true)) L.bad("Meta robots obsahuje noindex: $rb") else L.ok("Meta robots: " + (rb ?: "nenastavené (indexovateľné)"))
    val lang = Regex("<html\\s[^>]*>", RegexOption.IGNORE_CASE).find(html)?.let { attrs(it.value)["lang"] }
    if (!lang.isNullOrEmpty()) L.ok("Jazyk: $lang") else L.wa("Chýba atribút lang.")
    if (meta("viewport") != null) L.ok("Viewport nastavený.") else L.wa("Chýba meta viewport.")
    val h1 = Regex("<h1[\\s>]", RegexOption.IGNORE_CASE).findAll(html).count()
    if (h1 == 1) L.ok("Jeden nadpis H1.") else L.wa("Počet H1: $h1 (odporúčaný je 1).")
    val imgs = Regex("<img\\s[^>]*>", RegexOption.IGNORE_CASE).findAll(html).map { attrs(it.value) }.toList()
    val noalt = imgs.count { !it.containsKey("alt") }
    if (noalt > 0) L.wa("Obrázky bez alt: $noalt z ${imgs.size}.") else L.ok("Všetky obrázky (${imgs.size}) majú alt.")
    listOf("og:title", "og:description", "og:image", "og:url").forEach { k -> prop(k)?.let { L.ok("$k: " + it.take(80)) } ?: L.wa("Chýba $k") }
    meta("twitter:card")?.let { L.ok("twitter:card: $it") } ?: L.wa("Chýba twitter:card.")
    val hl = links.filter { (it["rel"] ?: "").contains("alternate", true) && it.containsKey("hreflang") }.map { it["hreflang"] }
    if (hl.isNotEmpty()) L.ok("hreflang: " + hl.joinToString(", "))
    L.l.add("")
    val u = URL(r.url)
    val origin = u.protocol + "://" + u.authority
    for (f in listOf("robots.txt", "sitemap.xml")) {
        val x = httpFetch("$origin/$f", maxBody = 200_000)
        if (x.error == null && x.status == 200 && x.body != null) L.ok("$f existuje (${x.body.size} B)") else L.wa("$f: " + (if (x.status > 0) "HTTP ${x.status}" else "nedostupný"))
        if (f == "robots.txt" && x.status == 200 && x.body != null) {
            val sm = Regex("^sitemap:\\s*(\\S+)", setOf(RegexOption.IGNORE_CASE, RegexOption.MULTILINE)).findAll(x.text).map { it.groupValues[1] }.toList()
            if (sm.isNotEmpty()) L.l.add("  Sitemap v robots.txt: " + sm.joinToString(", "))
        }
    }
    val errs = L.l.count { it.startsWith("✗") }
    return r.url + "\n" + (if (errs > 0) "Chýb: $errs" else "Bez kritických chýb.") + "\n\n" + L.l.joinToString("\n")
}

// ───────────────────────── Kontrola odkazov ─────────────────────────

fun linkCheck(url: String): String {
    val r = httpFetch(url)
    if (r.error != null) throw Exception(r.error)
    if (r.body == null || r.isBinary) throw Exception("Odpoveď nie je HTML.")
    val base = URL(r.url)
    val all = LinkedHashSet<String>()
    Regex("<a\\s[^>]*>", RegexOption.IGNORE_CASE).findAll(r.text).forEach { a ->
        val href = attrs(a.value)["href"]?.trim() ?: return@forEach
        if (href.isEmpty() || href.startsWith("#") || Regex("^(mailto|tel|javascript|data):", RegexOption.IGNORE_CASE).containsMatchIn(href)) return@forEach
        val abs = runCatching { URL(base, htmlDecode(href)).toString().substringBefore('#') }.getOrNull() ?: return@forEach
        if (abs.startsWith("http://") || abs.startsWith("https://")) all.add(abs)
    }
    val todo = all.take(24)
    val pool = Executors.newFixedThreadPool(6)
    class Res(val url: String, val status: Int, val loc: String?, val error: String?, val internal: Boolean)
    val res = try {
        pool.invokeAll(todo.map { l ->
            Callable {
                var x = httpFetch(l, method = "HEAD", follow = false, readBody = false, timeoutMs = 8000)
                if (x.error != null || x.status >= 400) x = httpFetch(l, follow = false, readBody = false, timeoutMs = 8000)
                Res(l, x.status, x.hops.lastOrNull()?.location, x.error, runCatching { URL(l).host == base.host }.getOrDefault(false))
            }
        }).map { it.get() }
    } finally { pool.shutdown() }
    val bad = res.filter { it.error != null || it.status >= 400 }
    fun f(x: Res) = (if (x.error != null) "CHYBA" else x.status.toString()).padEnd(7) + (if (x.internal) "int  " else "ext  ") + x.url +
        (if (x.loc != null) "\n            → ${x.loc}" else "") + (if (x.error != null) "  (${x.error})" else "")
    val out = mutableListOf("Odkazov na stránke: ${all.size} · skontrolovaných: ${res.size} · chybných: ${bad.size}", "")
    if (bad.isNotEmpty()) { out.add("Chybné odkazy"); bad.forEach { out.add(f(it)) }; out.add("") }
    out.add("Všetky skontrolované"); res.forEach { out.add(f(it)) }
    return out.joinToString("\n")
}

// ───────────────────────── Porty ─────────────────────────

fun portScan(host0: String, spec: String): String {
    val host = host0.trim().removePrefix("http://").removePrefix("https://").substringBefore('/').substringBefore(':').ifEmpty { throw Exception("Zadaj hostiteľa.") }
    val ports = spec.split(Regex("[,\\s]+")).filter { it.isNotBlank() }.map {
        it.toIntOrNull()?.takeIf { p -> p in 1..65535 } ?: throw Exception("Neplatný port: $it")
    }.distinct()
    if (ports.isEmpty() || ports.size > 10) throw Exception("Zadaj 1 až 10 portov.")
    class P(val port: Int, val open: Boolean, val err: String, val ms: Long)
    val pool = Executors.newFixedThreadPool(ports.size)
    val res = try {
        pool.invokeAll(ports.map { p ->
            Callable {
                val t0 = System.nanoTime()
                try {
                    Socket().use { it.connect(InetSocketAddress(host, p), 4000) }
                    P(p, true, "", (System.nanoTime() - t0) / 1_000_000)
                } catch (e: Exception) {
                    val msg = when {
                        e is SocketTimeoutException -> "časový limit"
                        e is UnknownHostException -> "neznámy hostiteľ"
                        e is ConnectException && (e.message ?: "").contains("refused", true) -> "zatvorený"
                        else -> e.message ?: e.javaClass.simpleName
                    }
                    P(p, false, msg, (System.nanoTime() - t0) / 1_000_000)
                }
            }
        }).map { it.get() }
    } finally { pool.shutdown() }
    return "$host: otvorených ${res.count { it.open }} z ${res.size}\n\nPort    Stav                  Čas\n" +
        res.sortedBy { it.port }.joinToString("\n") { it.port.toString().padEnd(8) + (if (it.open) "otvorený" else it.err).padEnd(22) + it.ms + " ms" }
}

// ───────────────────────── Kontrola e-mailu ─────────────────────────

fun mailReport(domain: String, mx: List<String>, txt: List<String>, dmarc: List<String>, dkim: Map<String, List<String>>, mtasts: List<String>): String {
    val L = Lines()
    val o = mutableListOf(domain, "", "MX")
    if (mx.isNotEmpty()) mx.forEach { o.add("✓ $it") } else o.add("✗ Žiadny MX záznam, doména nemôže prijímať poštu.")
    o.add(""); o.add("SPF")
    val spf = txt.filter { Regex("^v=spf1\\b", RegexOption.IGNORE_CASE).containsMatchIn(it) }
    if (spf.isEmpty()) L.bad("SPF záznam chýba.") else {
        if (spf.size > 1) L.bad("Viac SPF záznamov, špecifikácia dovoľuje len jeden.")
        val r = spf[0]
        L.l.add("  $r")
        val all = Regex("\\s([-~?+]?)all\\b", RegexOption.IGNORE_CASE).find(r)
        if (all != null) {
            when (all.groupValues[1]) {
                "-" -> L.ok("Končí -all (prísne).")
                "~" -> L.wa("Končí ~all (mäkké zlyhanie), zváž -all.")
                else -> L.bad("Mechanizmus all je " + (all.groupValues[1].ifEmpty { "+" }) + "all, povoľuje kohokoľvek.")
            }
        } else if (r.contains("redirect=")) L.ok("Používa redirect.") else L.wa("Chýba mechanizmus all.")
        val n = Regex("(?:^|\\s)[-~?+]?(?:include:|a\\b|mx\\b|ptr\\b|exists:|redirect=)", RegexOption.IGNORE_CASE).findAll(r).count()
        if (n > 10) L.bad("Približne $n DNS vyhľadávaní (limit je 10).") else L.ok("Približne $n z 10 DNS vyhľadávaní (len priame, bez vnorených).")
    }
    o.addAll(L.l); L.l.clear()
    o.add(""); o.add("DMARC")
    val dm = dmarc.filter { it.startsWith("v=DMARC1", true) }
    if (dm.isEmpty()) L.bad("DMARC záznam chýba (_dmarc).") else {
        val r = dm[0]
        val p = Regex("\\bp=(\\w+)", RegexOption.IGNORE_CASE).find(r)?.groupValues?.get(1) ?: ""
        L.l.add("  $r")
        if (p.equals("reject", true) || p.equals("quarantine", true)) L.ok("Politika p=$p.") else L.wa("Politika p=none, iba monitoring.")
        if (Regex("\\brua=", RegexOption.IGNORE_CASE).containsMatchIn(r)) L.ok("Posiela agregované reporty (rua).") else L.wa("Chýba rua, nedostaneš reporty.")
    }
    o.addAll(L.l); L.l.clear()
    o.add(""); o.add("DKIM")
    if (dkim.isNotEmpty()) dkim.keys.forEach { o.add("✓ Selektor $it") } else o.add("! V skúšaných selektoroch sa nič nenašlo. Zadaj vlastný selektor.")
    o.add(""); o.add("MTA-STS")
    o.add(if (mtasts.any { it.contains("v=STSv1", true) }) "✓ MTA-STS je nastavené." else "! MTA-STS nie je nastavené (voliteľné).")
    return o.joinToString("\n")
}

// ───────────────────────── RDAP ─────────────────────────

private fun fd(x: Any?): String = (x as? String)?.let {
    runCatching { OffsetDateTime.parse(it).atZoneSameInstant(ZoneId.systemDefault()).format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM).withLocale(Locale("sk", "SK"))) }.getOrDefault(it)
} ?: "—"

private fun ev(x: Map<*, *>, a: String): Any? = (x["events"] as? List<*>)?.firstOrNull { (it as? Map<*, *>)?.get("eventAction") == a }?.let { (it as Map<*, *>)["eventDate"] }

private fun vfn(e: Any?): String? {
    val v = ((e as? Map<*, *>)?.get("vcardArray") as? List<*>)?.getOrNull(1) as? List<*> ?: return null
    return v.firstOrNull { (it as? List<*>)?.getOrNull(0) == "fn" }?.let { (it as List<*>).getOrNull(3) as? String }
}

fun rdapLookup(q0: String): String {
    val q = q0.trim().removePrefix("http://").removePrefix("https://").substringBefore('/').lowercase()
    if (q.isEmpty()) throw Exception("Zadaj doménu alebo IP adresu.")
    val ip = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(q) || q.contains(':')
    val url = if (ip) "https://rdap.org/ip/$q" else "https://rdap.org/domain/" + IDN.toASCII(q)
    val r = httpFetch(url, headers = listOf("Accept" to "application/rdap+json, application/json"), maxBody = 500_000)
    if (r.error != null) throw Exception(r.error)
    if (r.status == 404) throw Exception("Záznam sa nenašiel.")
    if (r.status >= 400) throw Exception("RDAP vrátil HTTP ${r.status}.")
    val x = Js.parse(r.text) as? Map<*, *> ?: throw Exception("Neplatná odpoveď RDAP.")
    fun s(k: String) = x[k]?.toString()
    val rows: List<Pair<String, String?>> = if (!ip) {
        val reg = (x["entities"] as? List<*>)?.firstOrNull { ((it as? Map<*, *>)?.get("roles") as? List<*>)?.contains("registrar") == true }
        listOf(
            "Doména" to s("ldhName"), "Stav" to (x["status"] as? List<*>)?.joinToString(", "),
            "Registrácia" to fd(ev(x, "registration")), "Posledná zmena" to fd(ev(x, "last changed")),
            "Expirácia" to fd(ev(x, "expiration")), "Registrátor" to vfn(reg),
            "Menné servery" to (x["nameservers"] as? List<*>)?.joinToString("\n" + " ".repeat(15)) { (it as? Map<*, *>)?.get("ldhName")?.toString() ?: "" }
        )
    } else listOf(
        "Názov" to s("name"), "Handle" to s("handle"), "Rozsah" to "${s("startAddress")} – ${s("endAddress")}",
        "Krajina" to s("country"), "Typ" to s("type"),
        "Vlastník" to (x["entities"] as? List<*>)?.mapNotNull { vfn(it) }?.joinToString(", "), "Registrácia" to fd(ev(x, "registration"))
    )
    return rows.joinToString("\n") { it.first.padEnd(15) + (it.second?.ifEmpty { null } ?: "—") }
}

// ───────────────────────── JWT overenie podpisu (JWKS) ─────────────────────────

private fun bi(m: Map<*, *>, k: String) = BigInteger(1, b64u(m[k] as? String ?: throw Exception("V JWK chýba '$k'.")))

private fun derFromRaw(sig: ByteArray): ByteArray {
    val n = sig.size / 2
    fun enc(b: ByteArray): ByteArray { val v = BigInteger(1, b).toByteArray(); return byteArrayOf(0x02, v.size.toByte()) + v }
    val body = enc(sig.copyOfRange(0, n)) + enc(sig.copyOfRange(n, sig.size))
    return if (body.size < 128) byteArrayOf(0x30, body.size.toByte()) + body else byteArrayOf(0x30, 0x81.toByte(), body.size.toByte()) + body
}

internal fun verifySig(alg: String, jwk: Map<*, *>, data: ByteArray, sig: ByteArray): Boolean {
    val bits = alg.substring(2)
    val hash = "SHA-$bits"
    return when {
        alg.startsWith("RS") || alg.startsWith("PS") -> {
            val pub = KeyFactory.getInstance("RSA").generatePublic(RSAPublicKeySpec(bi(jwk, "n"), bi(jwk, "e")))
            val s = if (alg.startsWith("RS")) Signature.getInstance("SHA${bits}withRSA") else Signature.getInstance("RSASSA-PSS").also {
                it.setParameter(PSSParameterSpec(hash, "MGF1", MGF1ParameterSpec(hash), bits.toInt() / 8, 1))
            }
            s.initVerify(pub); s.update(data); s.verify(sig)
        }
        alg.startsWith("ES") -> {
            val curve = when (jwk["crv"]) { "P-256" -> "secp256r1"; "P-384" -> "secp384r1"; "P-521" -> "secp521r1"; else -> throw Exception("Nepodporovaná krivka ${jwk["crv"]}.") }
            val ap = AlgorithmParameters.getInstance("EC"); ap.init(ECGenParameterSpec(curve))
            val spec = ap.getParameterSpec(ECParameterSpec::class.java)
            val pub = KeyFactory.getInstance("EC").generatePublic(ECPublicKeySpec(ECPoint(bi(jwk, "x"), bi(jwk, "y")), spec))
            val s = Signature.getInstance("SHA${bits}withECDSA")
            s.initVerify(pub); s.update(data); s.verify(derFromRaw(sig))
        }
        else -> throw Exception("Algoritmus $alg nie je podporovaný (RS, PS a ES 256 až 512).")
    }
}

fun jwksVerify(token: String, jwksUrl0: String): Pair<String, Boolean> {
    val p = token.trim().split('.')
    if (p.size != 3) throw Exception("JWT musí mať 3 časti oddelené bodkou.")
    val h = runCatching { Js.parse(String(b64u(p[0]))) as Map<*, *> }.getOrNull() ?: throw Exception("Hlavičku tokenu sa nepodarilo dekódovať.")
    val pl = runCatching { Js.parse(String(b64u(p[1]))) as Map<*, *> }.getOrNull() ?: throw Exception("Payload tokenu sa nepodarilo dekódovať.")
    val alg = h["alg"]?.toString() ?: throw Exception("V hlavičke chýba alg.")
    val kid = h["kid"]?.toString()
    val iss = pl["iss"]?.toString()
    var jwksUrl = jwksUrl0.trim()
    if (jwksUrl.isEmpty()) {
        if (iss.isNullOrEmpty()) throw Exception("Token neobsahuje iss, zadaj URL JWKS.")
        val b = iss.trimEnd('/')
        val a = httpFetch("$b/.well-known/jwks.json", maxBody = 300_000)
        if (a.error == null && a.status == 200 && a.text.contains("\"keys\"")) jwksUrl = "$b/.well-known/jwks.json"
        else {
            val c = httpFetch("$b/.well-known/openid-configuration", maxBody = 300_000)
            val u = if (c.error == null && c.status == 200) (runCatching { Js.parse(c.text) as Map<*, *> }.getOrNull()?.get("jwks_uri") as? String) else null
            jwksUrl = u ?: throw Exception("JWKS sa z iss nepodarilo zistiť. Zadaj URL ručne.")
        }
    }
    val r = httpFetch(jwksUrl, maxBody = 500_000)
    if (r.error != null) throw Exception(r.error)
    if (r.status != 200) throw Exception("JWKS vrátil HTTP ${r.status}.")
    val keys = ((runCatching { Js.parse(r.text) as Map<*, *> }.getOrNull() ?: throw Exception("JWKS nie je platný JSON."))["keys"] as? List<*>)
        ?.mapNotNull { it as? Map<*, *> } ?: throw Exception("JWKS neobsahuje pole keys.")
    val kty = if (alg.startsWith("ES")) "EC" else "RSA"
    var cand = keys.filter { it["kty"] == kty && it["use"] != "enc" }
    if (kid != null) cand = cand.filter { it["kid"] == kid }.ifEmpty { throw Exception("V JWKS sa nenašiel kľúč s kid=$kid.") }
    if (cand.isEmpty()) throw Exception("V JWKS nie je vhodný kľúč.")
    val data = (p[0] + "." + p[1]).toByteArray(Charsets.US_ASCII)
    val sig = b64u(p[2])
    var valid = false
    var lastErr: Exception? = null
    for (k in cand) { try { if (verifySig(alg, k, data, sig)) { valid = true; break } } catch (e: Exception) { lastErr = e } }
    if (!valid && lastErr != null && cand.size == 1) throw Exception("Overenie zlyhalo: ${lastErr.message}")
    val now = Instant.now().epochSecond
    val exp = (pl["exp"] as? Number)?.toLong()
    val nbf = (pl["nbf"] as? Number)?.toLong()
    val out = "Podpis       ${if (valid) "platný" else "NEPLATNÝ"}\nAlgoritmus   $alg\nkid          ${kid ?: "—"}\nJWKS         $jwksUrl\nIssuer       ${iss ?: "—"}\n" +
        "Platnosť     " + (if (exp == null) "bez exp" else (if (exp < now) "expirovaný" else "platný") + " (${fmtEpoch(exp)})") +
        (if (nbf != null) "\nnbf          " + (if (nbf > now) "ešte neplatný" else "v poriadku") + " (${fmtEpoch(nbf)})" else "")
    return out to valid
}
