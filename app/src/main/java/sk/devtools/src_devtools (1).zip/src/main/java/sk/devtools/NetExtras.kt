package sk.devtools

// Doplnkové sieťové nástroje. Všetky funkcie sú blokujúce – volaj ich z Dispatchers.IO.

import java.net.ConnectException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.security.KeyStore
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.security.interfaces.ECPublicKey
import java.security.interfaces.RSAPublicKey
import java.time.Duration
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

// ───────────────────────── User-Agent ─────────────────────────

val UAS = listOf(
    "Predvolený" to "DevTools/1.0",
    "Android" to "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    "iPhone" to "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
    "Desktop" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Googlebot" to "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
    "curl" to "curl/8.7.1"
)

fun uaOf(name: String) = UAS.firstOrNull { it.first == name }?.second ?: UAS[0].second

// Pridá User-Agent na začiatok hlavičiek, ak nie je predvolený a používateľ si nenastavil vlastný.
fun withUa(h: List<Pair<String, String>>, ua: String): List<Pair<String, String>> =
    if (ua == UAS[0].first || h.any { it.first.equals("User-Agent", true) }) h else listOf("User-Agent" to uaOf(ua)) + h

fun parseHeaders(t: String): List<Pair<String, String>> = t.lines().mapNotNull { l ->
    val i = l.indexOf(':')
    if (i <= 0) null else l.substring(0, i).trim() to l.substring(i + 1).trim()
}

// ───────────────────────── Export cURL ─────────────────────────

private fun shq(s: String) = "'" + s.replace("'", "'\\''") + "'"

fun toCurl(
    url: String, method: String, headers: List<Pair<String, String>>, body: String?,
    basic: Pair<String, String>?, bearer: String?, follow: Boolean
): String {
    val p = mutableListOf("curl")
    if (method == "HEAD") p.add("-I") else if (method != "GET") p.add("-X $method")
    if (follow) p.add("-L")
    headers.forEach { p.add("-H " + shq(it.first + ": " + it.second)) }
    if (basic != null) p.add("-u " + shq(basic.first + ":" + basic.second))
    else if (!bearer.isNullOrBlank()) p.add("-H " + shq("Authorization: Bearer " + bearer.trim()))
    if (!body.isNullOrEmpty() && method != "GET" && method != "HEAD") p.add("--data-raw " + shq(body))
    p.add(shq(normalizeUrl(url)))
    return p.joinToString(" \\\n  ")
}

internal fun Resp.hv(name: String): String? =
    headers.filter { it.first.equals(name, true) }.joinToString(", ") { it.second }.ifEmpty { null }

private fun dur(sec: Long): String = when {
    sec < 60 -> "$sec s"
    sec < 3600 -> "${sec / 60} min"
    sec < 86400 -> "${sec / 3600} h"
    else -> "${sec / 86400} dní"
}

// ───────────────────────── SSL / TLS certifikát ─────────────────────────

// Na zistenie certifikátu sa pripojíme aj k serveru s neplatným certifikátom; dôveryhodnosť vyhodnotíme zvlášť.
internal val TRUST_ALL = object : X509TrustManager {
    override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {}
    override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {}
    override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
}

private fun dn(name: String, key: String): String? =
    Regex("(?:^|,)\\s*" + key + "=((?:\\\\.|[^,])+)").find(name)?.groupValues?.get(1)?.replace("\\", "")

private fun fp(c: X509Certificate): String =
    MessageDigest.getInstance("SHA-256").digest(c.encoded).joinToString(":") { "%02X".format(it) }

private fun keyInfo(c: X509Certificate): String = when (val k = c.publicKey) {
    is RSAPublicKey -> "RSA ${k.modulus.bitLength()} bit"
    is ECPublicKey -> "EC ${k.params.order.bitLength()} bit"
    else -> k.algorithm
}

private val DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm 'UTC'").withZone(ZoneOffset.UTC)

fun tlsInfo(input: String): String {
    val t = input.trim().removePrefix("https://").removePrefix("http://").substringBefore('/').substringAfterLast('@')
    val host = t.substringBefore(':').ifEmpty { throw Exception("Zadaj hostiteľa.") }
    val port = if (t.contains(':')) (t.substringAfter(':').toIntOrNull()?.takeIf { it in 1..65535 } ?: throw Exception("Neplatný port.")) else 443

    val ctx = SSLContext.getInstance("TLS").apply { init(null, arrayOf<TrustManager>(TRUST_ALL), null) }
    val raw = Socket()
    raw.connect(InetSocketAddress(host, port), 8000)
    raw.soTimeout = 8000
    val s = ctx.socketFactory.createSocket(raw, host, port, true) as SSLSocket
    class Hs(val chain: List<X509Certificate>, val protocol: String, val cipher: String, val nameOk: Boolean)
    val hs = try {
        s.startHandshake()
        val sess = s.session
        Hs(
            sess.peerCertificates.filterIsInstance<X509Certificate>(), sess.protocol, sess.cipherSuite,
            runCatching { HttpsURLConnection.getDefaultHostnameVerifier().verify(host, sess) }.getOrDefault(false)
        )
    } finally {
        runCatching { s.close() }
    }
    val chain = hs.chain
    val protocol = hs.protocol
    val cipher = hs.cipher
    val nameOk = hs.nameOk
    if (chain.isEmpty()) throw Exception("Server neposlal žiadny certifikát.")

    val trustErr = runCatching {
        val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        tmf.init(null as KeyStore?)
        val tm = tmf.trustManagers.filterIsInstance<X509TrustManager>().first()
        tm.checkServerTrusted(chain.toTypedArray(), "RSA")
    }.exceptionOrNull()

    val leaf = chain[0]
    val left = Duration.between(Instant.now(), leaf.notAfter.toInstant()).toDays()
    val sb = StringBuilder()
    sb.append("$host:$port\n")
    sb.append("Protokol: $protocol  ·  Šifra: $cipher\n\n")
    sb.append(if (trustErr == null) "✓ Certifikát je dôveryhodný (overené systémovými koreňovými CA).\n" else "✗ Certifikát nie je dôveryhodný: ${trustErr.message ?: trustErr.javaClass.simpleName}\n")
    sb.append(if (nameOk) "✓ Názov hostiteľa sedí s certifikátom.\n" else "✗ Názov hostiteľa $host nesedí s certifikátom.\n")
    sb.append(when {
        left < 0 -> "✗ Certifikát expiroval pred ${-left} dňami.\n"
        Instant.now().isBefore(leaf.notBefore.toInstant()) -> "✗ Certifikát ešte nie je platný.\n"
        left < 14 -> "! Certifikát expiruje o $left dní.\n"
        else -> "✓ Platný ešte $left dní.\n"
    })
    sb.append("\nReťazec: ${chain.size} " + (if (chain.size == 1) "certifikát" else if (chain.size < 5) "certifikáty" else "certifikátov") + "\n")

    chain.forEachIndexed { i, c ->
        val self = c.subjectX500Principal == c.issuerX500Principal
        val role = when {
            i == 0 -> "Koncový certifikát"
            self -> "Koreňový certifikát"
            else -> "Sprostredkujúci certifikát"
        }
        val subj = c.subjectX500Principal.name
        val iss = c.issuerX500Principal.name
        sb.append("\n[${i + 1}] $role\n")
        sb.append("Subjekt: ${dn(subj, "CN") ?: subj}" + (dn(subj, "O")?.let { "  ($it)" } ?: "") + "\n")
        sb.append("Vydavateľ: ${dn(iss, "CN") ?: iss}" + (dn(iss, "O")?.let { "  ($it)" } ?: "") + (if (self) "  (self-signed)" else "") + "\n")
        sb.append("Platnosť: ${DATE_FMT.format(c.notBefore.toInstant())} až ${DATE_FMT.format(c.notAfter.toInstant())}\n")
        if (i == 0) {
            val san = runCatching {
                c.subjectAlternativeNames?.mapNotNull { e -> if (e[0] == 2 || e[0] == 7) e[1] as? String else null }
            }.getOrNull().orEmpty()
            if (san.isNotEmpty()) sb.append("Alternatívne názvy: " + san.take(12).joinToString(", ") + (if (san.size > 12) " (+${san.size - 12} ďalších)" else "") + "\n")
        }
        sb.append("Kľúč: ${keyInfo(c)}  ·  Podpis: ${c.sigAlgName}\n")
        sb.append("Sériové číslo: ${c.serialNumber.toString(16).uppercase()}\n")
        sb.append("SHA-256: ${fp(c)}\n")
    }
    return sb.toString().trimEnd()
}

// ───────────────────────── CORS ─────────────────────────

fun corsTest(url: String, origin: String, method: String, reqHeaders: String, ua: String): String {
    val o = origin.trim().ifEmpty { throw Exception("Zadaj Origin.") }
    val base = withUa(emptyList(), ua)
    val rh = reqHeaders.split(',', ' ').map { it.trim().lowercase() }.filter { it.isNotEmpty() }

    val preH = base + listOf("Origin" to o, "Access-Control-Request-Method" to method) +
        (if (rh.isNotEmpty()) listOf("Access-Control-Request-Headers" to rh.joinToString(",")) else emptyList())
    val pre = httpFetch(url, "OPTIONS", preH, readBody = false, follow = false)
    val act = httpFetch(url, method, base + listOf("Origin" to o), readBody = false, follow = false)

    var bad = 0
    val out = StringBuilder()
    fun ok(t: String) { out.append("  ✓ $t\n") }
    fun wa(t: String) { out.append("  ! $t\n") }
    fun no(t: String) { bad++; out.append("  ✗ $t\n") }

    fun section(title: String, r: Resp, isPre: Boolean) {
        out.append("$title → ")
        if (r.error != null) { out.append("chyba\n"); no(r.error); out.append("\n"); return }
        out.append("HTTP ${r.status} ${r.statusText}".trim() + "\n")
        r.headers.filter { it.first.startsWith("access-control-", true) || it.first.equals("vary", true) }
            .forEach { out.append("    ${it.first}: ${it.second}\n") }
        val acao = r.hv("access-control-allow-origin")
        val creds = r.hv("access-control-allow-credentials")?.equals("true", true) == true
        when {
            acao == null -> no("Chýba Access-Control-Allow-Origin, prehliadač odpoveď zablokuje.")
            acao == "*" -> if (creds) no("Hodnotu * nemožno kombinovať s Allow-Credentials: true.") else ok("Povolené sú všetky originy (*).")
            acao == o -> ok("Origin $o je povolený.")
            else -> no("Povolený je iba $acao, nie $o.")
        }
        if (acao != null && acao != "*" && r.hv("vary")?.contains("origin", true) != true) wa("Chýba Vary: Origin, cache môže vrátiť odpoveď pre iný origin.")
        if (creds) ok("Odpoveď povoľuje cookies a autorizačné údaje (credentials).")
        if (isPre) {
            if (r.status !in 200..299) no("Preflight musí vrátiť stav 2xx, server vrátil ${r.status}.")
            val am = r.hv("access-control-allow-methods")?.split(',')?.map { it.trim().uppercase() }
            val simple = method in listOf("GET", "HEAD", "POST")
            if (am == null) { if (simple) wa("Chýba Access-Control-Allow-Methods (pre $method nie je nutné).") else no("Chýba Access-Control-Allow-Methods.") }
            else if (method.uppercase() in am || "*" in am) ok("Metóda $method je povolená.") else no("Metóda $method nie je v zozname: ${am.joinToString(", ")}.")
            if (rh.isNotEmpty()) {
                val ah = r.hv("access-control-allow-headers")?.split(',')?.map { it.trim().lowercase() }
                if (ah == null) no("Chýba Access-Control-Allow-Headers, hlavičky ${rh.joinToString(", ")} sú zablokované.")
                else {
                    val miss = rh.filter { it !in ah && "*" !in ah }
                    if (miss.isEmpty()) ok("Hlavičky ${rh.joinToString(", ")} sú povolené.") else no("Nepovolené hlavičky: ${miss.joinToString(", ")}.")
                }
            }
            r.hv("access-control-max-age")?.let { ok("Preflight sa cachuje $it s.") }
        } else {
            r.hv("access-control-expose-headers")?.let { ok("JavaScript uvidí hlavičky: $it") }
        }
        out.append("\n")
    }

    section("Preflight (OPTIONS)", pre, true)
    section("Skutočná požiadavka ($method)", act, false)
    out.append(if (bad == 0) "Výsledok: z originu $o by prehliadač požiadavku povolil." else "Výsledok: prehliadač by požiadavku zablokoval (chýb: $bad).")
    return out.toString()
}

// ───────────────────────── Cache a CDN ─────────────────────────

private val CDN_HEADERS = listOf(
    "cf-ray" to "Cloudflare", "x-amz-cf-id" to "Amazon CloudFront", "x-amz-cf-pop" to "Amazon CloudFront",
    "x-vercel-id" to "Vercel", "x-nf-request-id" to "Netlify", "x-azure-ref" to "Azure Front Door",
    "x-fastly-request-id" to "Fastly", "x-sucuri-id" to "Sucuri", "x-akamai-transformed" to "Akamai",
    "x-github-request-id" to "GitHub Pages", "x-bunny-cache-state" to "BunnyCDN", "x-served-by" to "Fastly / Varnish"
)

fun cacheCheck(url: String, ua: String): String {
    val r = httpFetch(url, headers = withUa(emptyList(), ua) + listOf("Accept-Encoding" to "gzip, br"), readBody = false)
    if (r.error != null) throw Exception(r.error)
    val out = StringBuilder("${r.url} (HTTP ${r.status})\n\n")
    fun ok(t: String) { out.append("✓ $t\n") }
    fun wa(t: String) { out.append("! $t\n") }

    out.append("Cache v prehliadači\n")
    val cc = r.hv("cache-control")
    val d = LinkedHashMap<String, String>()
    cc?.split(',')?.map { it.trim().lowercase() }?.filter { it.isNotEmpty() }?.forEach {
        d[it.substringBefore('=').trim()] = it.substringAfter('=', "").trim().trim('"')
    }
    if (cc != null) out.append("Cache-Control: $cc\n")
    val maxAge = d["max-age"]?.toLongOrNull()
    val sMax = d["s-maxage"]?.toLongOrNull()
    when {
        "no-store" in d -> wa("Odpoveď sa nikdy neukladá (no-store).")
        "no-cache" in d -> wa("Každé použitie sa musí revalidovať (no-cache).")
        maxAge != null && maxAge > 0 -> ok("Prehliadač drží kópiu ${dur(maxAge)}" + (if ("immutable" in d) " a nerevaliduje (immutable)." else "."))
        maxAge == 0L -> wa("max-age=0: kópia je hneď zastaraná.")
        cc == null && r.hv("expires") == null -> wa("Chýba Cache-Control aj Expires, prehliadač použije len heuristiku.")
    }
    if (sMax != null) ok("Zdieľané cache (CDN) držia kópiu ${dur(sMax)} (s-maxage).")
    if ("private" in d) wa("private: ukladá len prehliadač, CDN nie.") else if ("public" in d) ok("public: smie ju ukladať aj CDN a proxy.")
    d["stale-while-revalidate"]?.toLongOrNull()?.let { ok("Po expirácii sa ${dur(it)} servíruje stará kópia počas obnovy.") }
    if ("must-revalidate" in d) out.append("  must-revalidate: po expirácii je povinná revalidácia.\n")
    r.hv("expires")?.let { out.append("Expires: $it\n") }
    r.hv("pragma")?.let { out.append("Pragma: $it\n") }
    r.hv("vary")?.let { out.append("Vary: $it\n") }

    out.append("\nRevalidácia\n")
    val etag = r.hv("etag")
    val lm = r.hv("last-modified")
    etag?.let { out.append("ETag: $it\n") }
    lm?.let { out.append("Last-Modified: $it\n") }
    if (etag == null && lm == null) wa("Chýba ETag aj Last-Modified, nie je možná podmienená požiadavka.")
    else {
        val cond = if (etag != null) listOf("If-None-Match" to etag) else listOf("If-Modified-Since" to lm!!)
        val c2 = httpFetch(r.url, headers = withUa(emptyList(), ua) + cond, readBody = false)
        if (c2.error != null) wa("Test podmienenej požiadavky zlyhal: ${c2.error}")
        else if (c2.status == 304) ok("Podmienená požiadavka vrátila 304, revalidácia funguje.")
        else wa("Podmienená požiadavka vrátila HTTP ${c2.status} namiesto 304.")
    }
    r.hv("age")?.toLongOrNull()?.let { out.append("Age: $it s (${dur(it)} v zdieľanej cache)\n") }
    r.hv("content-encoding")?.let { out.append("Kompresia: $it\n") } ?: r.hv("content-type")?.let {
        if (it.contains("text", true) || it.contains("json", true) || it.contains("javascript", true) || it.contains("xml", true)) wa("Textová odpoveď bez kompresie (Content-Encoding).")
    }

    out.append("\nCDN a proxy\n")
    val found = LinkedHashSet<String>()
    CDN_HEADERS.forEach { (h, n) -> if (r.hv(h) != null) found.add(n) }
    val server = r.hv("server")?.lowercase() ?: ""
    val via = r.hv("via")?.lowercase() ?: ""
    if ("cloudflare" in server) found.add("Cloudflare")
    if ("akamai" in server) found.add("Akamai")
    if ("cloudfront" in via) found.add("Amazon CloudFront")
    if ("varnish" in via || r.hv("x-varnish") != null) found.add("Varnish")
    if ("vercel" in server) found.add("Vercel")
    if ("netlify" in server) found.add("Netlify")
    if (found.isEmpty()) out.append("Žiadna známa CDN sa nezistila.\n") else ok("Detekované: " + found.joinToString(", "))
    listOf("server", "via", "cf-cache-status", "x-cache", "x-cache-status", "x-cache-hits", "x-served-by", "x-varnish", "server-timing").forEach { h ->
        r.hv(h)?.let { out.append("$h: $it\n") }
    }
    return out.toString().trimEnd()
}

// ───────────────────────── Ping (TCP) ─────────────────────────

fun tcpPing(host0: String, port: Int, n: Int): String {
    val host = host0.trim().removePrefix("http://").removePrefix("https://").substringBefore('/').substringAfterLast('@').substringBefore(':')
        .ifEmpty { throw Exception("Zadaj hostiteľa.") }
    if (port !in 1..65535) throw Exception("Neplatný port.")
    val t0 = System.nanoTime()
    val addr = try { InetAddress.getByName(host) } catch (e: Exception) { throw Exception("Hostiteľ sa nepodarilo vyhľadať.") }
    val dns = (System.nanoTime() - t0) / 1e6
    val sb = StringBuilder("PING $host (${addr.hostAddress})  ·  TCP port $port\n")
    sb.append("DNS: %.0f ms\n\n".format(Locale.ROOT, dns))
    val times = mutableListOf<Double>()
    var lost = 0
    for (i in 1..n) {
        val s = System.nanoTime()
        try {
            Socket().use { it.connect(InetSocketAddress(addr, port), 3000) }
            val ms = (System.nanoTime() - s) / 1e6
            times.add(ms)
            sb.append("$i: %.1f ms\n".format(Locale.ROOT, ms))
        } catch (e: Exception) {
            if (e is ConnectException && (e.message ?: "").contains("refused", true)) {
                val ms = (System.nanoTime() - s) / 1e6
                times.add(ms)
                sb.append("$i: %.1f ms (port zatvorený, hostiteľ odpovedá)\n".format(Locale.ROOT, ms))
            } else {
                lost++
                sb.append("$i: " + (if (e is SocketTimeoutException) "časový limit" else (e.message ?: e.javaClass.simpleName)) + "\n")
            }
        }
        if (i < n) Thread.sleep(250)
    }
    sb.append("\nOdoslaných: $n, prijatých: ${n - lost}, strata: ${lost * 100 / n} %\n")
    if (times.isNotEmpty()) {
        val avg = times.average()
        val jit = if (times.size > 1) times.zipWithNext { a, b -> Math.abs(a - b) }.average() else 0.0
        sb.append("min / priem. / max: %.1f / %.1f / %.1f ms  ·  jitter %.1f ms".format(Locale.ROOT, times.min(), avg, times.max(), jit))
    }
    return sb.toString()
}
