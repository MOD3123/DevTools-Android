@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)

package sk.devtools

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

private fun cleanHost(s: String) = s.trim().lowercase().removePrefix("http://").removePrefix("https://").substringBefore('/').substringAfterLast('@').substringBefore(':')

@Composable
fun CurlTool() = Page("cURL príkaz", "Vlož príkaz cURL a spusti ho, alebo ho prevedz na fetch či Python.") {
    var t by rememberSaveable { mutableStateOf("") }
    var m by rememberSaveable { mutableStateOf("fetch (JS)") }
    Field(t, { t = it }, "curl -X POST 'https://api.example.com/items' -H 'Content-Type: application/json' -d '{\"a\":1}'", lines = 5)
    Run("Spustiť", t.isNotBlank()) {
        withContext(Dispatchers.IO) {
            val o = curlParse(t)
            if (o.url.isEmpty()) throw Exception("V príkaze chýba URL.")
            val j = o.user.indexOf(':')
            val basic = if (o.user.isEmpty()) null else (if (j < 0) o.user else o.user.substring(0, j)) to (if (j < 0) "" else o.user.substring(j + 1))
            httpFetch(o.url, curlMethod(o), curlHeaders(o), o.body.ifEmpty { null }, basic, follow = o.follow).report()
        }
    }
    Chips(listOf("fetch (JS)", "Python requests"), m) { m = it }
    if (t.isNotBlank()) {
        val r = remember(t, m) {
            runCatching {
                val o = curlParse(t)
                if (o.url.isEmpty()) throw Exception("V príkaze chýba URL.")
                curlConvert(o, m.startsWith("fetch"))
            }
        }
        Res(r, "Prevod")
    }
}

@Composable
fun MailTool() = Page("Kontrola e-mailu", "Kontrola MX, SPF, DMARC, DKIM a MTA-STS domény s upozorneniami.") {
    var d by rememberSaveable { mutableStateOf("") }
    var sel by rememberSaveable { mutableStateOf("") }
    Field(d, { d = it }, "example.com")
    Field(sel, { sel = it }, "Selektory DKIM (voliteľné): default, google, selector1", mono = false)
    Run("Skontrolovať", d.isNotBlank()) {
        val dom = cleanHost(d)
        val mx = dnsData(dom, "MX")
        val txt = dnsData(dom, "TXT")
        val dmarc = runCatching { dnsData("_dmarc.$dom", "TXT") }.getOrDefault(emptyList())
        val mts = runCatching { dnsData("_mta-sts.$dom", "TXT") }.getOrDefault(emptyList())
        val sels = sel.split(',', ' ').map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty {
            listOf("default", "google", "selector1", "selector2", "k1", "k2", "s1", "s2", "mail", "dkim", "smtp")
        }
        val dkim = coroutineScope {
            sels.map { s -> async { s to runCatching { dnsData("$s._domainkey.$dom", "TXT") }.getOrDefault(emptyList()) } }.awaitAll()
        }.filter { (_, v) -> v.any { it.contains("v=DKIM1", true) || it.contains("p=") } }.toMap()
        mailReport(dom, mx, txt, dmarc, dkim, mts)
    }
}

@Composable
fun RdapTool() = Page("WHOIS (RDAP)", "Registrátor, dátumy a menné servery domény, pri IP adrese vlastník siete.") {
    var q by rememberSaveable { mutableStateOf("") }
    Field(q, { q = it }, "example.com alebo 8.8.8.8")
    Run("Vyhľadať", q.isNotBlank()) { withContext(Dispatchers.IO) { rdapLookup(q) } }
}

@Composable
fun PortTool() = Page("Kontrola portov", "Zistí, či sú TCP porty servera otvorené (max. 10 portov naraz).") {
    var h by rememberSaveable { mutableStateOf("") }
    var p by rememberSaveable { mutableStateOf("22,80,443") }
    Field(h, { h = it }, "example.com alebo IP")
    Field(p, { p = it }, "Porty (oddelené čiarkou)")
    Run("Skontrolovať", h.isNotBlank()) { withContext(Dispatchers.IO) { portScan(h, p) } }
}

@Composable
fun SechdrTool() = Page("Bezpečnostné hlavičky", "Audit HSTS, CSP, X-Content-Type-Options, X-Frame-Options, Referrer-Policy a Permissions-Policy.") {
    var u by rememberSaveable { mutableStateOf("") }
    Field(u, { u = it }, "https://example.com")
    Run("Skontrolovať", u.isNotBlank()) { withContext(Dispatchers.IO) { securityHeaders(u) } }
}

@Composable
fun PganTool() = Page("Analýza stránky", "SEO kontrola: title, description, canonical, robots, Open Graph, nadpisy, obrázky, robots.txt a sitemap.xml.") {
    var u by rememberSaveable { mutableStateOf("") }
    Field(u, { u = it }, "https://example.com")
    Run("Analyzovať", u.isNotBlank()) { withContext(Dispatchers.IO) { pageAnalysis(u) } }
}

@Composable
fun LinkchkTool() = Page("Kontrola odkazov", "Nájde odkazy na stránke a otestuje ich stavové kódy. Skontroluje prvých 24 unikátnych odkazov.") {
    var u by rememberSaveable { mutableStateOf("") }
    Field(u, { u = it }, "https://example.com")
    Run("Skontrolovať", u.isNotBlank()) { withContext(Dispatchers.IO) { linkCheck(u) } }
}

@Composable
fun JwksTool() = Page("JWT overenie podpisu", "Overí podpis tokenu verejnými kľúčmi JWKS (RS, PS a ES 256 až 512). Ak URL nezadáš, zistí sa z iss tokenu.") {
    var t by rememberSaveable { mutableStateOf("") }
    var u by rememberSaveable { mutableStateOf("") }
    Field(t, { t = it }, "Token", lines = 4)
    Field(u, { u = it }, "URL JWKS (voliteľné)")
    Run("Overiť podpis", t.isNotBlank()) { withContext(Dispatchers.IO) { jwksVerify(t, u).first } }
}
