@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)

package sk.devtools

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp

// Licencia samotnej aplikácie. Kým ich nevyplníš, sekcia „Licencia aplikácie“ sa nezobrazí.
// Príklad: APP_LICENSE = "GPL-3.0-or-later", APP_SOURCE_URL = "https://github.com/tvoje-meno/DevTools"
private val APP_LICENSE: String? = null
private val APP_COPYRIGHT: String? = null
private val APP_SOURCE_URL: String? = null

private class Lib(val name: String, val by: String, val license: String, val url: String, val note: String)

private val LIBS = listOf(
    Lib(
        "Jetpack Compose a Material 3", "Google / Android Open Source Project", "Apache-2.0",
        "https://developer.android.com/jetpack/compose", "Používateľské rozhranie aplikácie vrátane ikon Material Icons."
    ),
    Lib(
        "AndroidX (Activity, Core)", "Google / Android Open Source Project", "Apache-2.0",
        "https://developer.android.com/jetpack/androidx", "Základné komponenty Androidu, výber súborov a spracovanie systémových udalostí."
    ),
    Lib(
        "Kotlin a kotlinx.coroutines", "JetBrains s.r.o. a prispievatelia", "Apache-2.0",
        "https://github.com/Kotlin/kotlinx.coroutines", "Programovací jazyk a asynchrónne spracovanie sieťových požiadaviek."
    ),
    Lib(
        "ZXing Core", "ZXing authors", "Apache-2.0",
        "https://github.com/zxing/zxing", "Tvorba a čítanie QR kódov a čiarových kódov. Beží lokálne, bez internetu."
    ),
    Lib(
        "Chrome DevTools Frontend", "The Chromium Authors", "BSD-3-Clause",
        "https://github.com/ChromeDevTools/devtools-frontend", "Rozhranie panelov v nástroji „Prehliadač s DevTools“. Súbory sa sťahujú pri použití nástroja."
    )
)

private class Svc(val name: String, val what: String)

private val SERVICES = listOf(
    Svc("ipwho.is", "Poloha a sieť pre IP adresu. Služba dostane IP adresu, ktorú zadáš do nástroja GeoIP."),
    Svc("api.ipify.org", "Zistenie tvojej verejnej IP adresy v nástroji Moja IP."),
    Svc("rdap.org", "Údaje o doméne alebo IP adrese (RDAP). Služba dostane doménu alebo IP, ktorú zadáš."),
    Svc("1.1.1.1 (Cloudflare) a 8.8.8.8 (Google)", "DNS servery pre nástroje DNS a kontrola e-mailových záznamov."),
    Svc("chrome-devtools-frontend.appspot.com", "Hostované súbory rozhrania DevTools pre vstavaný prehliadač."),
    Svc("openstreetmap.org", "Len odkaz na mapu, otvorí sa v prehliadači až po ťuknutí.")
)

@Composable
fun LicTool() = Page(
    "Licencie open source",
    "DevTools je postavený na open source knižniciach. Tu je ich zoznam, licencie a externé služby, na ktoré sa niektoré nástroje pripájajú."
) {
    val uri = LocalUriHandler.current
    fun open(u: String) { runCatching { uri.openUri(u) } }

    if (APP_LICENSE != null) {
        SectionTitle("Licencia aplikácie")
        LCard {
            Text("DevTools", style = MaterialTheme.typography.titleMedium, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            Text("Licencia: $APP_LICENSE", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
            APP_COPYRIGHT?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            APP_SOURCE_URL?.let { u -> TextButton(onClick = { open(u) }, contentPadding = PaddingValues(0.dp)) { Text("Zdrojový kód: $u") } }
        }
    }

    SectionTitle("Použité knižnice")
    LIBS.forEach { l ->
        LCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                Text(
                    l.name, style = MaterialTheme.typography.titleMedium,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(12.dp))
                Text(l.license, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            }
            Text(l.by, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(l.note, style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = { open(l.url) }, contentPadding = PaddingValues(0.dp)) { Text(l.url.removePrefix("https://")) }
        }
    }

    SectionTitle("Externé služby")
    Text(
        "Väčšina nástrojov beží lokálne. Tieto služby sa použijú len pri nástrojoch, ktoré ich potrebujú. Aplikácia neobsahuje analytiku ani reklamy.",
        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    SERVICES.forEach { s ->
        LCard {
            Text(s.name, style = MaterialTheme.typography.titleSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            Text(s.what, style = MaterialTheme.typography.bodyMedium)
        }
    }

    SectionTitle("Plné znenie licencií")
    LicenseText("Apache License 2.0", "licenses/apache-2.0.txt")
    LicenseText("BSD 3-Clause (The Chromium Authors)", "licenses/bsd-3-clause-chromium.txt")
}

@Composable
private fun SectionTitle(t: String) {
    Text(t, style = MaterialTheme.typography.titleMedium, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 8.dp, top = 8.dp))
}

@Composable
private fun LCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(4.dp), content = content)
    }
}

@Composable
private fun LicenseText(title: String, path: String) {
    val ctx = LocalContext.current
    var open by rememberSaveable(path) { mutableStateOf(false) }
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = RoundedCornerShape(28.dp),
        modifier = Modifier.fillMaxWidth().clickable { open = !open }
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(if (open) "Skryť" else "Zobraziť", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        }
    }
    if (open) {
        val text = remember(path) {
            runCatching { ctx.assets.open(path).bufferedReader().use { it.readText() } }.getOrDefault("Text licencie sa nepodarilo načítať.")
        }
        Out(text, title)
    }
}
