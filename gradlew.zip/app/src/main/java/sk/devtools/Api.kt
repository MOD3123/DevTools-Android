package sk.devtools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// Pevný Cloudflare Worker, v aplikácii sa nedá zmeniť.
const val WORKER = "https://devtools.kvetinky.workers.dev/"

suspend fun http(url: String, method: String = "GET", body: String? = null): String = withContext(Dispatchers.IO) {
    val c = URL(url).openConnection() as HttpURLConnection
    c.requestMethod = method
    c.connectTimeout = 15000
    c.readTimeout = 30000
    if (body != null) {
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toByteArray()) }
    }
    val s = if (c.responseCode < 400) c.inputStream else (c.errorStream ?: c.inputStream)
    s.bufferedReader().use { it.readText() }
}

suspend fun api(p: JSONObject): JSONObject {
    val r = try { JSONObject(http(WORKER, "POST", p.toString())) }
    catch (e: Exception) { throw Exception("Worker je nedostupný alebo vrátil neplatnú odpoveď.") }
    if (r.has("error")) throw Exception(r.optString("error"))
    return r
}

fun JSONObject.s(k: String): String = if (isNull(k)) "" else optString(k)

fun hops(d: JSONObject): String {
    val a = d.getJSONArray("hops")
    return (0 until a.length()).joinToString("\n\n") { i ->
        val h = a.getJSONObject(i)
        val st = if (h.optInt("status") > 0) "${h.optInt("status")} ${h.s("statusText")}" else "chyba"
        val ms = if (h.isNull("ms")) "" else "  ${h.optInt("ms")} ms"
        var t = "${h.optInt("n")}. $st$ms\n${h.s("url")}"
        if (h.s("location").isNotEmpty()) t += "\n→ ${h.s("location")}"
        if (h.s("error").isNotEmpty()) t += "\n${h.s("error")}"
        t
    }
}
