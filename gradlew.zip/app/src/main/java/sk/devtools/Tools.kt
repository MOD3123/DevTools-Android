package sk.devtools

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector

class Tool(val id: String, val title: String, val desc: String, val icon: ImageVector, val ui: @Composable () -> Unit)

val TOOLS = listOf(
    Tool("req", "HTTP požiadavky", "Odošle požiadavku cez Worker a ukáže presmerovania.", Icons.Default.Send) { ReqTool() },
    Tool("ip", "What is my IP", "Tvoja verejná IP adresa a informácie o zariadení.", Icons.Default.LocationOn) { IpTool() },
    Tool("dns", "DNS lookup", "Záznamy A, AAAA, CNAME, MX, NS, TXT a reverzné PTR.", Icons.Default.Search) { DnsTool() },
    Tool("ts", "Unix timestamp", "Prevod medzi timestampom a dátumom.", Icons.Default.DateRange) { TsTool() },
    Tool("b64", "Base64", "Kódovanie a dekódovanie Base64.", Icons.Default.Create) { B64Tool() },
    Tool("url", "URL encode / decode", "Kódovanie a dekódovanie URL.", Icons.Default.Share) { UrlTool() },
    Tool("base", "Číselné sústavy", "Prevod medzi BIN, OCT, DEC a HEX.", Icons.Default.Build) { BaseTool() },
    Tool("json", "JSON beautifier", "Formátovanie a validácia JSON.", Icons.Default.List) { JsonTool() },
    Tool("hash", "Hash", "MD5, SHA-1, SHA-256 a SHA-512 textu.", Icons.Default.Lock) { HashTool() },
    Tool("uuid", "UUID generátor", "Náhodné UUID v4.", Icons.Default.Star) { UuidTool() },
    Tool("pw", "Generátor hesiel", "Náhodné heslo cez kryptografický generátor.", Icons.Default.AccountBox) { PwTool() },
    Tool("case", "Text a veľkosť písmen", "Prevod na veľké, malé, camelCase, snake_case a ďalšie.", Icons.Default.Edit) { CaseTool() },
    Tool("pct", "Percentá", "Základné výpočty s percentami.", Icons.Default.Info) { PctTool() },
    Tool("vat", "DPH kalkulačka", "Prepočet medzi cenou bez DPH a s DPH.", Icons.Default.ShoppingCart) { VatTool() },
)

// Poradie skupín: Domov je vždy prvý.
val GROUPS = listOf(
    "Prehľad" to listOf("home"),
    "Online funkcie" to listOf("req", "ip"),
    "Doména a sieť" to listOf("dns"),
    "Konvertory" to listOf("ts", "b64", "url", "base"),
    "Dáta a bezpečnosť" to listOf("json", "hash", "uuid", "pw"),
    "Text" to listOf("case"),
    "Kalkulačky a hry" to listOf("pct", "vat"),
)
