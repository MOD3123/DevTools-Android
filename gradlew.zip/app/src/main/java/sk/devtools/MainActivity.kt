@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)

package sk.devtools

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { DevToolsTheme { Surface(color = MaterialTheme.colorScheme.surface) { App() } } }
    }
}

// Material 3 Expressive: expresívny pohyb (pružinové animácie) + dynamické farby (Android 12+).
// Motív sa vždy riadi systémom (svetlý / tmavý), bez prepínača.
@Composable
fun DevToolsTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val cs = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme(
            primary = Color(0xFFB4C5FF), onPrimary = Color(0xFF00297A), primaryContainer = Color(0xFF2B3F8F),
            onPrimaryContainer = Color(0xFFDCE1FF), secondary = Color(0xFFC1C5DD), tertiary = Color(0xFFE5B9DE)
        )
        else -> lightColorScheme(
            primary = Color(0xFF4358A9), onPrimary = Color.White, primaryContainer = Color(0xFFDCE1FF),
            onPrimaryContainer = Color(0xFF00164E), secondary = Color(0xFF595D72), tertiary = Color(0xFF75546F)
        )
    }
    MaterialExpressiveTheme(colorScheme = cs, motionScheme = MotionScheme.expressive(), content = content)
}

@Composable
fun App() {
    var cur by rememberSaveable { mutableStateOf("home") }
    var q by rememberSaveable { mutableStateOf("") }
    var searching by rememberSaveable { mutableStateOf(false) }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val go: (String) -> Unit = { id -> cur = id; q = ""; searching = false; scope.launch { drawer.close() } }
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    val tool = TOOLS.find { it.id == cur }

    BackHandler(enabled = cur != "home" || searching) {
        if (searching) { searching = false; q = "" } else cur = "home"
    }
    ModalNavigationDrawer(drawerState = drawer, drawerContent = { ModalDrawerSheet { DrawerContent(cur, go) } }) {
        Scaffold(
            modifier = Modifier.nestedScroll(scroll.nestedScrollConnection),
            containerColor = MaterialTheme.colorScheme.surface,
            topBar = {
                val nav: @Composable () -> Unit = {
                    IconButton({ scope.launch { drawer.open() } }) { Icon(Icons.Default.Menu, "Menu") }
                }
                val act: @Composable RowScope.() -> Unit = {
                    FilledTonalIconButton({ searching = !searching; if (!searching) q = "" }) {
                        Icon(if (searching) Icons.Default.Close else Icons.Default.Search, "Hľadať")
                    }
                    Spacer(Modifier.width(8.dp))
                }
                if (searching) {
                    TopAppBar(title = { SearchField(q) { q = it } }, navigationIcon = nav, actions = act)
                } else {
                    LargeFlexibleTopAppBar(
                        title = { Text(tool?.title ?: "DevTools", fontWeight = FontWeight.Bold) },
                        navigationIcon = nav, actions = act, scrollBehavior = scroll
                    )
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when {
                    q.isNotBlank() -> Results(q, go)
                    tool == null -> HomeScreen(go)
                    else -> tool.ui()
                }
            }
        }
    }
}

@Composable
fun SearchField(q: String, on: (String) -> Unit) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { fr.requestFocus() }
    TextField(
        value = q, onValueChange = on, singleLine = true,
        placeholder = { Text("Hľadať nástroj") },
        shape = RoundedCornerShape(50),
        colors = TextFieldDefaults.colors(
            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent, errorIndicatorColor = Color.Transparent,
            focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh
        ),
        modifier = Modifier.fillMaxWidth().focusRequester(fr)
    )
}

@Composable
fun DrawerContent(cur: String, go: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(12.dp)) {
        item {
            Text("DevTools", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp))
        }
        GROUPS.forEach { (g, ids) ->
            item {
                Text(g, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 6.dp))
            }
            items(ids) { id ->
                val t = TOOLS.find { it.id == id }
                NavigationDrawerItem(
                    label = { Text(t?.title ?: "Domov") },
                    icon = { Icon(t?.icon ?: Icons.Default.Home, null) },
                    selected = cur == id, onClick = { go(id) }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(go: (String) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(160.dp),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(40.dp, 16.dp, 40.dp, 16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Nástroje pre vývojárov", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("${TOOLS.size} nástrojov, väčšina beží lokálne.", style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
        }
        GROUPS.filter { it.first != "Prehľad" }.forEach { (g, ids) ->
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(g, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 8.dp, top = 12.dp))
            }
            items(ids.mapNotNull { id -> TOOLS.find { it.id == id } }) { t ->
                Surface(
                    onClick = { go(t.id) },
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        ShapedIcon(t.icon, TOOLS.indexOf(t))
                        Text(t.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, minLines = 2)
                    }
                }
            }
        }
    }
}

@Composable
fun Results(q: String, go: (String) -> Unit) {
    val r = TOOLS.filter { it.title.contains(q, true) || it.desc.contains(q, true) }
    if (r.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) {
        Text("Nič sa nenašlo", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(r) { t ->
            ListItem(
                headlineContent = { Text(t.title, fontWeight = FontWeight.SemiBold) },
                supportingContent = { Text(t.desc) },
                leadingContent = { ShapedIcon(t.icon, TOOLS.indexOf(t), 44.dp) },
                colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                modifier = Modifier.clip(RoundedCornerShape(24.dp)).clickable { go(t.id) }
            )
        }
    }
}
