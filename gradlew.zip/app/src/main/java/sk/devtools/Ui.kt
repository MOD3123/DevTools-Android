@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)

package sk.devtools

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Obsah nástroja. Nadpis zobrazuje veľký skladací horný panel v App(), tu ostáva len popis a obsah.
@Composable
fun Page(@Suppress("UNUSED_PARAMETER") title: String, desc: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(desc, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        content()
        Spacer(Modifier.height(24.dp))
    }
}

// Expressive tvary (MaterialShapes) pre ikonové kontajnery – každý nástroj má vlastný tvar.
private val ShapePool get() = listOf(
    MaterialShapes.Cookie9Sided, MaterialShapes.Clover4Leaf, MaterialShapes.Sunny,
    MaterialShapes.Cookie6Sided, MaterialShapes.Pentagon, MaterialShapes.Flower,
    MaterialShapes.SoftBurst, MaterialShapes.Gem
)

@Composable
fun ShapedIcon(icon: ImageVector, index: Int, size: Dp = 52.dp) {
    val shape = ShapePool.let { it[index.mod(it.size)] }.toShape()
    Box(
        Modifier.size(size).clip(shape).background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, Modifier.size(size * 0.46f), tint = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
fun Field(v: String, on: (String) -> Unit, label: String, lines: Int = 1, mono: Boolean = true) =
    OutlinedTextField(
        value = v, onValueChange = on, label = { Text(label) },
        modifier = Modifier.fillMaxWidth(), minLines = lines, shape = RoundedCornerShape(20.dp),
        textStyle = LocalTextStyle.current.copy(fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default)
    )

@Composable
fun Out(t: String, label: String = "Výsledok") {
    val cb = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) { if (copied) { delay(1600); copied = false } }
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier.fillMaxWidth().animateContentSize()
    ) {
        Column(Modifier.padding(start = 20.dp, end = 12.dp, top = 8.dp, bottom = 18.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                FilledTonalButton(
                    onClick = { cb.setText(AnnotatedString(t)); copied = true },
                    shapes = ButtonDefaults.shapes(),
                    contentPadding = PaddingValues(horizontal = 14.dp)
                ) {
                    if (copied) { Icon(Icons.Default.Check, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)) }
                    Text(if (copied) "Skopírované" else "Kopírovať")
                }
            }
            Spacer(Modifier.height(4.dp))
            SelectionContainer { Text(t, style = MaterialTheme.typography.bodyLarge, fontFamily = FontFamily.Monospace) }
        }
    }
}

// Skupina prepínacích tlačidiel s tvarom, ktorý sa pri stlačení plynulo mení.
@Composable
fun Chips(opts: List<String>, sel: String, on: (String) -> Unit) =
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        opts.forEach { o ->
            ToggleButton(checked = o == sel, onCheckedChange = { on(o) }, shapes = ToggleButtonDefaults.shapes()) { Text(o) }
        }
    }

@Composable
fun Chk(label: String, v: Boolean, on: (Boolean) -> Unit) =
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { on(!v) }.padding(vertical = 2.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(v, null)
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }

@Composable
fun Act(label: String, onClick: () -> Unit) =
    Button(
        onClick = onClick, shapes = ButtonDefaults.shapes(),
        modifier = Modifier.heightIn(min = 56.dp), contentPadding = PaddingValues(horizontal = 28.dp)
    ) { Text(label, style = MaterialTheme.typography.titleMedium) }

@Composable
fun Run(label: String, enabled: Boolean = true, block: suspend () -> String) {
    var out by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val sc = rememberCoroutineScope()
    Button(
        onClick = { busy = true; sc.launch { out = try { block() } catch (e: Exception) { e.message ?: "Chyba" }; busy = false } },
        enabled = enabled && !busy, shapes = ButtonDefaults.shapes(),
        modifier = Modifier.heightIn(min = 56.dp), contentPadding = PaddingValues(horizontal = 28.dp)
    ) {
        if (busy) { LoadingIndicator(Modifier.size(28.dp)); Spacer(Modifier.width(12.dp)) }
        Text(if (busy) "Pracujem…" else label, style = MaterialTheme.typography.titleMedium)
    }
    if (out.isNotEmpty()) Out(out)
}
