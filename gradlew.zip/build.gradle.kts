// F:\Android projekty\DevTools\build.gradle.kts (Hlavný root projekt)
plugins {
    id("com.android.application") version "9.1.0" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false // 👈 PRIDAŤ: apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false // 👈 PRIDAŤ: apply false
}
